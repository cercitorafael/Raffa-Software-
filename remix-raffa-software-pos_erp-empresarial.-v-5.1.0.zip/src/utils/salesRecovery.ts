import { Sale, Customer } from '../types';
import { supabase } from '../lib/supabase';
import { mapSupabaseToSale } from '../lib/supabaseSync';
import { offlineDB } from './indexedDB';

/**
 * Normalizes strings for resilient customer-to-sale matching.
 * Strips whitespace, accents, punctuation, and converts to lowercase.
 */
export function normalizeText(str?: string | null): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

/**
 * Robustly matches a sale record to a customer entity using:
 * 1. Exact Customer ID match
 * 2. NIF / Tax Number match (excluding generic 999999990)
 * 3. Cleaned name exact match
 * 4. Substring containment (e.g. "AGRO-AVES" matches "AGRO-AVES, LDA")
 */
export function matchSaleToCustomer(sale: Sale | any, customer: Customer | any): boolean {
  if (!sale || !customer) return false;

  // 1. Direct ID match
  const saleCustId = sale.customerId || sale.customer_id;
  if (saleCustId && customer.id && String(saleCustId) === String(customer.id)) {
    return true;
  }

  // 2. Tax Number (NIF) match
  const sTax = (sale.customerTaxNumber || sale.customer_tax_number || sale.customerNif || '').trim();
  const cTax = (customer.taxNumber || customer.tax_number || '').trim();
  if (sTax && cTax && sTax !== '999999990' && cTax !== '999999990' && sTax === cTax) {
    return true;
  }

  // 3. Name comparisons
  const sName = normalizeText(sale.customerName || sale.customer_name);
  const cName = normalizeText(customer.name);

  if (!sName || !cName || sName === 'consumidorfinal' || cName === 'consumidorfinal') {
    return false;
  }

  if (sName === cName) {
    return true;
  }

  // Substring match for business extensions (LDA, E.I., SU, etc.)
  if (sName.length >= 4 && cName.length >= 4) {
    if (sName.includes(cName) || cName.includes(sName)) {
      return true;
    }
  }

  return false;
}

/**
 * Retrieves all sales belonging to a specific customer from a list of sales.
 */
export function getCustomerPurchases(customer: Customer, allSales: Sale[]): Sale[] {
  if (!customer || !Array.isArray(allSales)) return [];
  return allSales.filter((s) => matchSaleToCustomer(s, customer));
}

/**
 * Calculates the total monetary volume spent by a customer across all sales.
 */
export function getCustomerTotalVolume(customer: Customer, allSales: Sale[]): number {
  const purchases = getCustomerPurchases(customer, allSales);
  return purchases.reduce((acc, s) => acc + (Number(s.total) || 0), 0);
}

/**
 * Recalculates and restores customer metrics (totalSpent, ordersCount, lastPurchaseDate)
 * based on all sales recorded from day 1 to today.
 */
export function reconcileCustomerMetrics(customers: Customer[], allSales: Sale[]): Customer[] {
  if (!Array.isArray(customers)) return [];
  const safeSales = Array.isArray(allSales) ? allSales : [];

  return customers.map((customer) => {
    const matchingSales = safeSales.filter((s) => matchSaleToCustomer(s, customer));
    const totalSpentFromSales = matchingSales.reduce((sum, s) => sum + (Number(s.total) || 0), 0);
    const ordersCountFromSales = matchingSales.length;

    // Find most recent purchase date
    let lastPurchaseDate = customer.lastPurchaseDate;
    if (matchingSales.length > 0) {
      const sortedByDate = [...matchingSales].sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      lastPurchaseDate = sortedByDate[0].date;
    }

    const effectiveTotalSpent = Math.max(Number(customer.totalSpent) || 0, totalSpentFromSales);
    const effectiveOrdersCount = Math.max(Number(customer.ordersCount) || 0, ordersCountFromSales);

    // Ensure loyalty points reflect at least 1 pt per 10 MT spent if not higher
    const calculatedPoints = Math.floor(effectiveTotalSpent / 10);
    const effectivePoints = Math.max(Number(customer.loyaltyPoints) || 0, calculatedPoints);

    return {
      ...customer,
      totalSpent: effectiveTotalSpent,
      ordersCount: effectiveOrdersCount,
      lastPurchaseDate,
      loyaltyPoints: effectivePoints,
    };
  });
}

/**
 * Fetches all sales without company restrictions from Supabase (from day 1 to today).
 * Supports pagination in chunks of 1000 so large databases are completely loaded.
 */
export async function fetchAllHistoricalSalesFromSupabase(options?: {
  targetCompanyId?: string;
  onProgress?: (loadedCount: number) => void;
}): Promise<{ sales: Sale[]; error?: string }> {
  try {
    const allRows: any[] = [];
    let offset = 0;
    const batchSize = 1000;
    let hasMore = true;

    while (hasMore) {
      const { data, error } = await supabase
        .from('vendas')
        .select('*')
        .order('date', { ascending: false })
        .range(offset, offset + batchSize - 1);

      if (error) {
        console.warn('Erro ao carregar vendas históricas do Supabase:', error.message);
        return {
          sales: allRows.map((r) => mapSupabaseToSale(r, options?.targetCompanyId)),
          error: error.message,
        };
      }

      if (!data || data.length === 0) {
        hasMore = false;
      } else {
        allRows.push(...data);
        if (options?.onProgress) {
          options.onProgress(allRows.length);
        }
        if (data.length < batchSize) {
          hasMore = false;
        } else {
          offset += batchSize;
        }
      }
    }

    const mappedSales = allRows.map((r) => mapSupabaseToSale(r, options?.targetCompanyId));
    return { sales: mappedSales };
  } catch (err: any) {
    console.error('Falha de rede ao consultar vendas do Supabase:', err);
    return { sales: [], error: err?.message || 'Falha de conexão com o Supabase' };
  }
}

/**
 * Master recovery function:
 * 1. Pulls all sales from Supabase
 * 2. Pulls all sales from IndexedDB offline storage
 * 3. Merges them with local in-memory/localStorage sales
 * 4. Reconciles and restores all customer purchasing records and totals
 */
export async function recoverAndReconcileAllSales(
  localSales: Sale[],
  localCustomers: Customer[],
  targetCompanyId?: string,
  knownOtherCompanyIds: string[] = []
): Promise<{
  allSales: Sale[];
  reconciledCustomers: Customer[];
  stats: {
    totalSalesCount: number;
    remoteSalesFound: number;
    offlineSalesFound: number;
    totalRevenue: number;
    customersRestoredCount: number;
    earliestSaleDate: string | null;
    latestSaleDate: string | null;
  };
  error?: string;
}> {
  // 1. Fetch remote sales from Supabase
  const remoteResult = await fetchAllHistoricalSalesFromSupabase({ targetCompanyId });
  const remoteSales = remoteResult.sales;

  // 2. Fetch offline sales from IndexedDB
  let offlineSales: Sale[] = [];
  try {
    offlineSales = await offlineDB.getAllSales();
  } catch (e) {
    console.warn('Não foi possível ler vendas do IndexedDB:', e);
  }

  // 3. Merge all sales deduplicating by ID and invoiceNumber
  const salesById = new Map<string, Sale>();
  const salesByInvoice = new Map<string, Sale>();

  const registerSale = (s: Sale) => {
    if (!s || !s.id) return;

    let effectiveCompanyId = s.companyId;
    if (targetCompanyId) {
      if (!effectiveCompanyId || effectiveCompanyId === 'comp-1' || !knownOtherCompanyIds.includes(effectiveCompanyId)) {
        effectiveCompanyId = targetCompanyId;
      }
    } else {
      effectiveCompanyId = effectiveCompanyId || 'comp-1';
    }

    const invoiceKey = s.invoiceNumber ? s.invoiceNumber.trim().toUpperCase() : null;
    const idKey = String(s.id);

    const existingById = salesById.get(idKey);
    const existingByInv = invoiceKey ? salesByInvoice.get(invoiceKey) : undefined;
    const existing = existingById || existingByInv;

    if (existing) {
      const merged: Sale = {
        ...existing,
        ...s,
        id: existing.id || s.id,
        companyId: effectiveCompanyId,
        items: s.items && s.items.length > 0 ? s.items : existing.items || [],
        payments: s.payments && s.payments.length > 0 ? s.payments : existing.payments || [],
        total: Number(s.total || existing.total || 0),
        subtotal: Number(s.subtotal || existing.subtotal || s.total || 0),
        taxTotal: Number(s.taxTotal || existing.taxTotal || 0),
        date: s.date || existing.date || new Date().toISOString(),
        status: s.status || existing.status || 'emitido',
        invoiceType: s.invoiceType || existing.invoiceType || 'FS',
      };
      salesById.set(String(merged.id), merged);
      if (invoiceKey) salesByInvoice.set(invoiceKey, merged);
    } else {
      const newSale: Sale = {
        ...s,
        companyId: effectiveCompanyId,
        items: Array.isArray(s.items) ? s.items : [],
        payments: Array.isArray(s.payments) ? s.payments : [],
        total: Number(s.total || 0),
        subtotal: Number(s.subtotal || s.total || 0),
        taxTotal: Number(s.taxTotal || 0),
        date: s.date || new Date().toISOString(),
        status: s.status || 'emitido',
        invoiceType: s.invoiceType || 'FS',
      };
      salesById.set(idKey, newSale);
      if (invoiceKey) salesByInvoice.set(invoiceKey, newSale);
    }
  };

  // Register existing local sales first
  (localSales || []).forEach(registerSale);
  // Register offline sales
  offlineSales.forEach(registerSale);
  // Register remote Supabase sales
  remoteSales.forEach(registerSale);

  const allSales = Array.from(salesById.values()).sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  // Cache to IndexedDB for offline durability
  try {
    await offlineDB.cacheSales(allSales);
  } catch (e) {
    console.warn('Aviso ao sincronizar IndexedDB de vendas:', e);
  }

  // 4. Reconcile customer totals
  const reconciledCustomers = reconcileCustomerMetrics(localCustomers, allSales);

  // 5. Update Supabase clientes table in the background for persisted accuracy
  try {
    for (const cust of reconciledCustomers) {
      if (cust.totalSpent > 0 || (cust.ordersCount || 0) > 0) {
        await supabase
          .from('clientes')
          .update({
            total_spent: cust.totalSpent,
            loyalty_points: cust.loyaltyPoints,
            updated_at: new Date().toISOString(),
          })
          .eq('id', cust.id);
      }
    }
  } catch (e) {
    console.warn('Aviso ao sincronizar métricas de clientes no Supabase:', e);
  }

  // 6. Compute statistics
  const totalRevenue = allSales.reduce((sum, s) => sum + (Number(s.total) || 0), 0);
  const earliestSaleDate = allSales.length > 0 ? allSales[allSales.length - 1].date : null;
  const latestSaleDate = allSales.length > 0 ? allSales[0].date : null;
  const customersRestoredCount = reconciledCustomers.filter(
    (c) => (c.totalSpent || 0) > 0 || (c.ordersCount || 0) > 0
  ).length;

  return {
    allSales,
    reconciledCustomers,
    stats: {
      totalSalesCount: allSales.length,
      remoteSalesFound: remoteSales.length,
      offlineSalesFound: offlineSales.length,
      totalRevenue,
      customersRestoredCount,
      earliestSaleDate,
      latestSaleDate,
    },
    error: remoteResult.error,
  };
}
