import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { supabase } from '../../lib/supabase';
import { formatCurrency, formatDate, formatExactDate, formatExactTime, formatExactDateTime } from '../../utils/crypto';
import {
  Boxes,
  ArrowUpDown,
  AlertTriangle,
  Plus,
  Package,
  Layers,
  Search,
  CheckCircle,
  FileSpreadsheet,
  TrendingUp,
  Tag,
  Warehouse as WarehouseIcon,
  Edit2,
  Trash2,
  Sliders,
  Eye,
  X,
  RefreshCw,
  ShieldAlert,
  Upload,
  Download,
  FileUp,
  FileDown,
  Percent,
  CheckSquare,
  ArrowRight,
  ArrowLeftRight,
  ListPlus,
  FileText,
  Check,
  Clock,
  Calendar,
  History,
  Info,
  Filter,
} from 'lucide-react';
import { Product, Warehouse, LotBatch, ProductCategory, VatRate } from '../../types';
import { defaultVatRates } from '../../mockData';
import { ProductImportExportModal } from './ProductImportExportModal';
import { CategoryManagementModal } from './CategoryManagementModal';
import { CategoryManagementTab } from './CategoryManagementTab';
import { InventoryExtractTab } from './InventoryExtractTab';
import { InterStoreTransfersTab } from './InterStoreTransfersTab';
import { PhysicalInventoryCountTab } from './PhysicalInventoryCountTab';

export interface StockModuleProps {
  initialTab?: 'overview' | 'categories' | 'warehouses' | 'lots' | 'movements' | 'inventory_extract' | 'transfer' | 'inventory_count' | 'reorder';
}

export const StockModule: React.FC<StockModuleProps> = ({ initialTab }) => {
  const {
    products,
    warehouses,
    stock,
    setStock,
    lots,
    stockMovements,
    stockTransfers,
    salesHistory,
    currentStore,
    currentCompany,
    currentUser,
    currencyDefinition,
    categories,
    suppliers,
    addProduct,
    updateProduct,
    deleteProduct,
    addWarehouse,
    updateWarehouse,
    deleteWarehouse,
    addLot,
    updateLot,
    deleteLot,
    transferStock,
    recordStockMovement,
    createStockAdjustment,
    deleteStockMovement,
    addPurchaseRequisition,
    hasPermission,
    requestConfirm,
    setActiveNavTab,
    notify,
  } = useApp();

  const companyVatRates: VatRate[] = currentCompany?.vatRates && currentCompany.vatRates.length > 0
    ? currentCompany.vatRates
    : defaultVatRates;

  const defaultTaxRateValue = typeof currentCompany?.defaultTaxRate === 'number'
    ? currentCompany.defaultTaxRate
    : (companyVatRates.find((v) => v.isDefault)?.rate ?? 16);

  const currencySymbol = currentCompany?.currencySymbol || currencyDefinition?.symbol || 'Mt';

  const [activeTab, setActiveTab] = useState<'overview' | 'categories' | 'warehouses' | 'lots' | 'movements' | 'inventory_extract' | 'transfer' | 'inventory_count' | 'reorder'>(
    initialTab || 'overview'
  );

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [selectedWarehouseFilter, setSelectedWarehouseFilter] = useState<string>('all');

  // Consulta de Stock Atual vs. Dias Passados
  const [stockDateMode, setStockDateMode] = useState<'current' | 'historical'>('current');
  const [historicalDate, setHistoricalDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().slice(0, 10);
  });

  // Filtro de Stock Disponível no Local Selecionado
  const [onlyWithStockInSelectedWarehouse, setOnlyWithStockInSelectedWarehouse] = useState(false);

  // Product Modals
  const [showNewProductModal, setShowNewProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [showImportExportModal, setShowImportExportModal] = useState(false);
  const [importExportInitialMode, setImportExportInitialMode] = useState<'import' | 'export'>('import');

  // Category Modal
  const [showCategoryModal, setShowCategoryModal] = useState(false);

  // Warehouse Modals
  const [showNewWarehouseModal, setShowNewWarehouseModal] = useState(false);
  const [editingWarehouse, setEditingWarehouse] = useState<Warehouse | null>(null);

  // Lot Modals
  const [showNewLotModal, setShowNewLotModal] = useState(false);
  const [editingLot, setEditingLot] = useState<LotBatch | null>(null);

  // Adicionar Stock via Supabase (Acionamento explícito por clique de botão)
  const [showAddStockModal, setShowAddStockModal] = useState(false);
  const [produtoSelecionado, setProdutoSelecionado] = useState<string>('');
  const [armazemSelecionado, setArmazemSelecionado] = useState<string>('');
  const [quantidadeStock, setQuantidadeStock] = useState<number>(1);
  const [isSubmittingStock, setIsSubmittingStock] = useState(false);

  // Movements Tab States (Search & Filter)
  const [movementSearch, setMovementSearch] = useState('');
  const [movementTypeFilter, setMovementTypeFilter] = useState<'all' | 'entrada' | 'saida' | 'transferencia' | 'ajuste' | 'devolucao'>('all');

  // Product Form State
  const [prodForm, setProdForm] = useState({
    name: '',
    sku: '',
    barcode: '',
    price: 9.90,
    costPrice: 4.50,
    taxRate: defaultTaxRateValue,
    category: categories[0]?.id || 'cat-bebidas',
    unit: 'un',
    minStock: 10,
    maxStock: 100,
    supplierId: suppliers[0]?.id || '',
    hasBatchControl: false,
    imageUrl: 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=300',
    description: '',
  });

  // Stock Adjustment Form State
  const [adjustWarehouseId, setAdjustWarehouseId] = useState<string>(warehouses[0]?.id || '');
  const [adjustNewQty, setAdjustNewQty] = useState<number>(0);
  const [adjustReason, setAdjustReason] = useState<string>('Contagem física de rotina');

  // Warehouse Form State
  const [whForm, setWhForm] = useState({
    name: '',
    code: '',
    location: '',
    isDefault: false,
    storeId: currentStore.id,
  });

  // Lot Form State
  const [lotForm, setLotForm] = useState({
    productId: products[0]?.id || '',
    warehouseId: warehouses[0]?.id || '',
    batchNumber: `LOT-2026-${Math.floor(100 + Math.random() * 900)}`,
    manufacturingDate: new Date().toISOString().split('T')[0],
    expiryDate: new Date(Date.now() + 365 * 86400000).toISOString().split('T')[0],
    initialQuantity: 50,
    currentQuantity: 50,
    supplierId: suppliers[0]?.id || '',
  });

  // Permissions check
  const canRead = hasPermission('stock', 'read') || currentUser?.role === 'admin';
  const canCreate = hasPermission('stock', 'create');
  const canEdit = hasPermission('stock', 'edit');
  const canDelete = hasPermission('stock', 'delete');

  // RBAC Restricted Access UI
  if (!canRead) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-[#0a0a0a] text-center space-y-4 select-none">
        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center shadow-lg">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <div className="max-w-md space-y-2">
          <h3 className="text-base font-serif font-bold text-white">
            Acesso Restrito ao Stock & Inventário
          </h3>
          <p className="text-xs text-neutral-400">
            O seu perfil atual (<strong>{currentUser?.name}</strong> &bull; {currentUser?.role?.toUpperCase()}) não tem permissão para aceder à gestão de stock, lotes, transferências e inventário.
          </p>
        </div>
        <div className="pt-2 flex items-center space-x-3">
          <button
            onClick={() => setActiveNavTab('pos')}
            className="px-4 py-2 bg-[#c5a47e] hover:bg-[#b5946e] text-neutral-950 font-bold text-xs rounded-xl cursor-pointer shadow-md transition-colors"
          >
            Ir para o Ponto de Venda (POS)
          </button>
        </div>
      </div>
    );
  }

  // Selected warehouse object for dynamic location labels
  const selectedWarehouseObj = useMemo(
    () => warehouses.find((w) => w.id === selectedWarehouseFilter),
    [warehouses, selectedWarehouseFilter]
  );
  const selectedWarehouseName = selectedWarehouseObj ? selectedWarehouseObj.name : 'Todos os Armazéns';

  // Cálculo de Stock Atual vs. Posição Reconstituída em Dias Passados
  const calculateProductStock = useMemo(() => {
    return (
      productId: string,
      warehouseId: string,
      mode: 'current' | 'historical',
      dateStr: string
    ): number => {
      // 1. Posição atual de stock no armazém selecionado ou global
      const matchingStock = stock.filter(
        (s) => s.productId === productId && (warehouseId === 'all' || s.warehouseId === warehouseId)
      );
      const currentQty = matchingStock.reduce((sum, s) => sum + Number(s.quantity || 0), 0);

      if (mode === 'current') {
        return currentQty;
      }

      // 2. Data de corte histórica: final do dia selecionado às 23:59:59.999
      const cutoffTime = new Date(`${dateStr}T23:59:59.999`).getTime();
      if (isNaN(cutoffTime)) return currentQty;

      // Reconstitui a posição matemática revertendo movimentos posteriores à data de corte
      let deltaAfter = 0;
      stockMovements.forEach((mov) => {
        if (mov.productId !== productId) return;
        if (warehouseId !== 'all' && mov.warehouseId !== warehouseId) return;
        const movDateStr = mov.timestamp || (mov as any).date;
        if (!movDateStr) return;
        const movTime = new Date(movDateStr).getTime();
        if (movTime > cutoffTime) {
          const qty = Number(mov.quantity || 0);
          const typeLower = String(mov.type || '').toLowerCase();
          if (typeLower.includes('entrada') || typeLower === 'devolucao' || typeLower.includes('compra')) {
            deltaAfter += qty;
          } else if (
            typeLower.includes('saida') ||
            typeLower === 'venda' ||
            typeLower === 'quebra' ||
            typeLower === 'perda' ||
            typeLower.includes('consumo')
          ) {
            deltaAfter -= qty;
          } else if (typeLower === 'ajuste') {
            const prevQ = (mov as any).previousQuantity;
            const newQ = (mov as any).newQuantity;
            if (typeof prevQ === 'number' && typeof newQ === 'number') {
              deltaAfter += (newQ - prevQ);
            }
          }
        }
      });

      const historicalQty = currentQty - deltaAfter;
      return Math.max(0, historicalQty);
    };
  }, [stock, stockMovements]);

  // Filtered Stock Table (Strictly alphabetical across all sectors with warehouse & stock filters)
  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        const q = searchQuery.toLowerCase();
        const matchesSearch =
          p.name.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q) ||
          (p.barcode && p.barcode.includes(q));
        const matchesCat = selectedCategoryFilter === 'all' || p.category === selectedCategoryFilter;
        if (!matchesSearch || !matchesCat) return false;

        // Filtro de Stock Disponível no Local Selecionado
        if (onlyWithStockInSelectedWarehouse) {
          const availableQty = calculateProductStock(p.id, selectedWarehouseFilter, stockDateMode, historicalDate);
          if (availableQty <= 0) return false;
        }

        return true;
      })
      .sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt', { sensitivity: 'base', numeric: true }));
  }, [
    products,
    searchQuery,
    selectedCategoryFilter,
    onlyWithStockInSelectedWarehouse,
    selectedWarehouseFilter,
    stockDateMode,
    historicalDate,
    calculateProductStock,
  ]);

  // Calculate Valuation & Stock Units according to active location and historical date
  const totalStockUnits = useMemo(() => {
    return products.reduce((sum, p) => {
      return sum + calculateProductStock(p.id, selectedWarehouseFilter, stockDateMode, historicalDate);
    }, 0);
  }, [products, selectedWarehouseFilter, stockDateMode, historicalDate, calculateProductStock]);

  const totalStockValue = useMemo(() => {
    return products.reduce((sum, p) => {
      const qty = calculateProductStock(p.id, selectedWarehouseFilter, stockDateMode, historicalDate);
      return sum + qty * (Number(p.costPrice) || 0);
    }, 0);
  }, [products, selectedWarehouseFilter, stockDateMode, historicalDate, calculateProductStock]);

  const lowStockProducts = useMemo(() => {
    return products.filter((p) => {
      const totalQty = calculateProductStock(p.id, selectedWarehouseFilter, stockDateMode, historicalDate);
      return totalQty <= p.minStock;
    });
  }, [products, selectedWarehouseFilter, stockDateMode, historicalDate, calculateProductStock]);

  // Map invoices to exact issuance date for precise movement timestamps
  const salesMap = useMemo(() => {
    const map = new Map<string, any>();
    (salesHistory || []).forEach((s) => {
      if (s.invoiceNumber) {
        map.set(s.invoiceNumber.trim().toUpperCase(), s);
      }
    });
    return map;
  }, [salesHistory]);

  // Movements sorted chronologically (newest first) with exact timestamp resolution and filtering
  const filteredAndSortedMovements = useMemo(() => {
    const list = [...stockMovements].map((mov) => {
      const ref = (mov.referenceDoc || '').trim().toUpperCase();
      const sale = ref ? salesMap.get(ref) : undefined;
      const exactTimestamp =
        (sale?.date && (mov.timestamp?.includes('21:27:56') || !mov.timestamp) ? sale.date : mov.timestamp) ||
        sale?.date ||
        mov.timestamp ||
        (mov as any).date ||
        (mov as any).createdAt ||
        '';
      return {
        ...mov,
        resolvedExactTimestamp: exactTimestamp,
      };
    });

    // Chronological sort: newest first
    list.sort((a, b) => {
      const timeA = new Date(a.resolvedExactTimestamp || 0).getTime();
      const timeB = new Date(b.resolvedExactTimestamp || 0).getTime();
      return timeB - timeA;
    });

    return list.filter((mov) => {
      if (movementTypeFilter !== 'all' && mov.type !== movementTypeFilter) {
        return false;
      }
      if (!movementSearch.trim()) return true;
      const q = movementSearch.toLowerCase().trim();
      const prod = products.find((p) => p.id === mov.productId);
      const prodName = (prod?.name || '').toLowerCase();
      const prodSku = (prod?.sku || '').toLowerCase();
      const refDoc = (mov.referenceDoc || '').toLowerCase();
      const reason = (mov.reason || '').toLowerCase();
      const movNum = (mov.movementNumber || '').toLowerCase();
      return (
        prodName.includes(q) ||
        prodSku.includes(q) ||
        refDoc.includes(q) ||
        reason.includes(q) ||
        movNum.includes(q)
      );
    });
  }, [stockMovements, salesMap, movementTypeFilter, movementSearch, products]);

  // Handle Save Product (Create or Edit) with strict validation & rigor
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const name = prodForm.name.trim();
    const sku = prodForm.sku.trim();

    if (!name || name.length < 2) {
      notify('Rigor de Registo: O nome do artigo é obrigatório e deve ter no mínimo 2 caracteres.', 'error');
      return;
    }

    if (!sku) {
      notify('Rigor de Registo: O código de referência / SKU é obrigatório.', 'error');
      return;
    }

    const price = Number(prodForm.price);
    if (isNaN(price) || price < 0) {
      notify('Rigor Financeiro: O preço de venda deve ser um número válido maior ou igual a zero.', 'error');
      return;
    }

    const costPrice = Number(prodForm.costPrice);
    if (isNaN(costPrice) || costPrice < 0) {
      notify('Rigor Financeiro: O preço de custo (CMP) deve ser um número válido maior ou igual a zero.', 'error');
      return;
    }

    if (editingProduct) {
      const success = updateProduct(editingProduct.id, {
        name,
        sku,
        barcode: prodForm.barcode.trim(),
        price,
        costPrice,
        taxRate: Number(prodForm.taxRate),
        category: prodForm.category,
        unit: prodForm.unit,
        minStock: Number(prodForm.minStock),
        maxStock: Number(prodForm.maxStock),
        supplierId: prodForm.supplierId,
        hasBatchControl: prodForm.hasBatchControl,
        imageUrl: prodForm.imageUrl,
        description: prodForm.description,
      });
      if (!success) return;
      setEditingProduct(null);
    } else {
      const success = addProduct({
        companyId: currentCompany.id,
        name,
        sku,
        barcode: prodForm.barcode.trim(),
        category: prodForm.category,
        price,
        costPrice,
        taxRate: Number(prodForm.taxRate),
        unit: prodForm.unit,
        minStock: Number(prodForm.minStock),
        maxStock: Number(prodForm.maxStock),
        supplierId: prodForm.supplierId,
        hasBatchControl: prodForm.hasBatchControl,
        imageUrl: prodForm.imageUrl,
        description: prodForm.description,
      });
      if (!success) return;
      setShowNewProductModal(false);
    }

    // Reset Form
    setProdForm({
      name: '',
      sku: '',
      barcode: '',
      price: 9.90,
      costPrice: 4.50,
      taxRate: defaultTaxRateValue,
      category: categories[0]?.id || 'cat-bebidas',
      unit: 'un',
      minStock: 10,
      maxStock: 100,
      supplierId: suppliers[0]?.id || '',
      hasBatchControl: false,
      imageUrl: 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=300',
      description: '',
    });
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setProdForm({
      name: prod.name,
      sku: prod.sku,
      barcode: prod.barcode,
      price: prod.price,
      costPrice: prod.costPrice,
      taxRate: prod.taxRate,
      category: prod.category,
      unit: prod.unit,
      minStock: prod.minStock,
      maxStock: prod.maxStock,
      supplierId: prod.supplierId || '',
      hasBatchControl: prod.hasBatchControl,
      imageUrl: prod.imageUrl || '',
      description: prod.description || '',
    });
  };

  const handleOpenAdjustStock = (prod: Product) => {
    const currentQty = stock.find((s) => s.productId === prod.id && s.warehouseId === currentStore.defaultWarehouseId)?.quantity || 0;
    setAdjustingProduct(prod);
    setAdjustWarehouseId(currentStore.defaultWarehouseId || warehouses[0]?.id || '');
    setAdjustNewQty(currentQty);
    setAdjustReason('Ajuste de inventário manual');
  };

  const handleSaveAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingProduct) return;
    createStockAdjustment(adjustingProduct.id, adjustWarehouseId, Number(adjustNewQty), adjustReason);
    setAdjustingProduct(null);
  };

  // 1. Inserção DEVE ficar dentro de uma função acionada por clique de botão:
  const handleAdicionarStock = async () => {
    if (!produtoSelecionado || !armazemSelecionado) {
      notify('Por favor, selecione o artigo e o armazém de destino.', 'warning');
      return;
    }

    try {
      setIsSubmittingStock(true);
      const { data, error } = await supabase.from('stock').insert({
        product_id: produtoSelecionado,
        warehouse_id: armazemSelecionado
      });
      if (error) console.error(error);

      // Atualiza o estado da aplicação e histórico de movimentos
      const qtyToAdd = Number(quantidadeStock) || 1;
      setStock((prev: any) => {
        const list = Array.isArray(prev) ? [...prev] : [];
        const existingIndex = list.findIndex(
          (s: any) =>
            (s.productId === produtoSelecionado || s.product_id === produtoSelecionado) &&
            (s.warehouseId === armazemSelecionado || s.warehouse_id === armazemSelecionado)
        );
        if (existingIndex >= 0) {
          list[existingIndex] = {
            ...list[existingIndex],
            quantity: (Number(list[existingIndex].quantity) || 0) + qtyToAdd,
          };
        } else {
          list.push({
            id: `stk-${Date.now()}`,
            companyId: currentCompany?.id || 'comp-1',
            productId: produtoSelecionado,
            warehouseId: armazemSelecionado,
            quantity: qtyToAdd,
            avgCost: 0,
          });
        }
        return list;
      });

      const prod = products.find((p) => p.id === produtoSelecionado);
      recordStockMovement({
        companyId: currentCompany?.id || 'comp-1',
        type: 'entrada',
        productId: produtoSelecionado,
        targetWarehouseId: armazemSelecionado,
        quantity: qtyToAdd,
        unitCost: prod?.costPrice || 0,
        referenceDoc: 'MANUAL-SUPABASE',
        reason: `Adição manual de stock: ${prod?.name || 'Artigo'}`,
        operatorId: currentUser?.id || 'user-1',
        date: new Date().toISOString(),
      });

      notify(`Stock adicionado com sucesso para ${prod?.name || 'o artigo'}!`, 'success');
      setShowAddStockModal(false);
    } catch (err) {
      console.error('Erro ao adicionar stock:', err);
      notify('Erro ao registar stock no Supabase.', 'error');
    } finally {
      setIsSubmittingStock(false);
    }
  };

  // 2. Se for buscar dados ao carregar a tela, o useEffect PRECISA dos colchetes vazios []:
  useEffect(() => {
    async function carregarStock() {
      const { data } = await supabase.from('stock').select('*');
      setStock(data);
    }
    carregarStock();
  }, []); // <--- Esses colchetes [] impedem o loop!

  // Warehouse Handlers
  const handleSaveWarehouse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!whForm.name || !whForm.code) return;

    if (editingWarehouse) {
      updateWarehouse(editingWarehouse.id, whForm);
      setEditingWarehouse(null);
    } else {
      addWarehouse({
        companyId: currentCompany.id,
        name: whForm.name,
        code: whForm.code,
        location: whForm.location,
        isDefault: whForm.isDefault,
        storeId: whForm.storeId,
      });
      setShowNewWarehouseModal(false);
    }
    setWhForm({ name: '', code: '', location: '', isDefault: false, storeId: currentStore.id });
  };

  // Lot Handlers
  const handleSaveLot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lotForm.batchNumber || !lotForm.productId) return;

    if (editingLot) {
      updateLot(editingLot.id, lotForm);
      setEditingLot(null);
    } else {
      addLot({
        productId: lotForm.productId,
        warehouseId: lotForm.warehouseId,
        batchNumber: lotForm.batchNumber,
        manufacturingDate: lotForm.manufacturingDate,
        expiryDate: lotForm.expiryDate,
        initialQuantity: Number(lotForm.initialQuantity),
        currentQuantity: Number(lotForm.currentQuantity),
        supplierId: lotForm.supplierId,
      });
      setShowNewLotModal(false);
    }
  };

    // 1-Click Requisition Generator
  const handleCreateRequisitionForLowStock = (prod: Product) => {
    const currentQty = stock.filter((s) => s.productId === prod.id).reduce((acc, s) => acc + s.quantity, 0);
    const qtyNeeded = prod.maxStock - currentQty;
    addPurchaseRequisition({
      companyId: currentCompany.id,
      requesterId: currentUser.id,
      requesterName: currentUser.name,
      department: 'Armazém / Stock',
      priority: 'alta',
      status: 'pendente',
      items: [
        {
          productId: prod.id,
          productName: prod.name,
          quantity: Math.max(10, qtyNeeded),
          estimatedUnitCost: prod.costPrice,
          total: Math.max(10, qtyNeeded) * prod.costPrice,
        },
      ],
      totalEstimated: Math.max(10, qtyNeeded) * prod.costPrice,
      notes: `Reposição automática de stock mínimo crítico para ${prod.sku}`,
    });
    notify(`Requisição de Compra criada com sucesso para reposição de ${prod.name}!`, 'success');
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#0a0a0a] text-[#e5e5e5]">
      {/* Header & Metric Bar */}
      <div className="bg-[#141414] border-b border-[#262626] px-6 py-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#c5a47e]/15 border border-[#c5a47e]/30 flex items-center justify-center text-[#c5a47e]">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-serif text-[#e5e5e5]">Stock & Inventário Multiarmazém</h1>
              <p className="text-xs text-neutral-400">
                Catálogo mestre, valorização CMP, lotes/validades e gestão de armazéns
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              id="stock-import-btn"
              onClick={() => {
                setImportExportInitialMode('import');
                setShowImportExportModal(true);
              }}
              className="px-3.5 py-2 bg-[#1a1a1a] hover:bg-[#242424] text-neutral-200 border border-[#333] hover:border-[#c5a47e]/40 font-medium text-xs rounded-lg transition-colors flex items-center space-x-1.5 shadow-xs cursor-pointer"
              title="Importar catálogo via Excel, CSV ou JSON"
            >
              <FileUp className="w-4 h-4 text-[#c5a47e]" />
              <span>Importar</span>
            </button>

            <button
              id="stock-export-btn"
              onClick={() => {
                setImportExportInitialMode('export');
                setShowImportExportModal(true);
              }}
              className="px-3.5 py-2 bg-[#1a1a1a] hover:bg-[#242424] text-neutral-200 border border-[#333] hover:border-[#c5a47e]/40 font-medium text-xs rounded-lg transition-colors flex items-center space-x-1.5 shadow-xs cursor-pointer"
              title="Exportar catálogo para Excel, CSV ou JSON"
            >
              <FileDown className="w-4 h-4 text-emerald-400" />
              <span>Exportar</span>
            </button>

            <button
              id="stock-categories-btn"
              onClick={() => setActiveTab('categories')}
              className={`px-3.5 py-2 border font-medium text-xs rounded-lg transition-colors flex items-center space-x-1.5 cursor-pointer shadow-xs ${
                activeTab === 'categories'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-[#1a1a1a] hover:bg-[#252525] text-amber-300 hover:text-amber-200 border-[#333] hover:border-amber-500/40'
              }`}
              title="Gerir categorias de artigos, famílias de produtos, cores e ícones"
            >
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Gestão de Categorias</span>
            </button>

            {canCreate && (
              <button
                id="btn-adicionar-stock-modal"
                onClick={() => {
                  setProdutoSelecionado(products[0]?.id || '');
                  setArmazemSelecionado(
                    selectedWarehouseFilter !== 'all'
                      ? selectedWarehouseFilter
                      : (currentStore.defaultWarehouseId || warehouses[0]?.id || '')
                  );
                  setQuantidadeStock(1);
                  setShowAddStockModal(true);
                }}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-lg transition-colors flex items-center space-x-1.5 shadow-xs cursor-pointer"
                title="Adicionar entrada de stock para um artigo num armazém (Supabase)"
              >
                <Boxes className="w-4 h-4" />
                <span>Adicionar Stock</span>
              </button>
            )}

            {canCreate && (
              <button
                onClick={() => {
                  setEditingProduct(null);
                  setShowNewProductModal(true);
                }}
                className="px-3.5 py-2 bg-[#c5a47e] hover:bg-[#b5946e] text-neutral-950 font-medium text-xs rounded-lg transition-colors flex items-center space-x-1.5 shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Novo Artigo</span>
              </button>
            )}
            {canCreate && (
              <button
                onClick={() => {
                  setEditingWarehouse(null);
                  setShowNewWarehouseModal(true);
                }}
                className="px-3.5 py-2 bg-[#1f1f1f] hover:bg-[#262626] text-neutral-200 border border-[#333] font-medium text-xs rounded-lg transition-colors flex items-center space-x-1.5 cursor-pointer"
              >
                <WarehouseIcon className="w-4 h-4 text-emerald-400" />
                <span>Novo Armazém</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick KPI Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 pt-3 border-t border-[#262626]">
          <div className="bg-[#0f0f0f] border border-[#262626] rounded-lg p-3">
            <div className="text-[11px] text-neutral-400 uppercase tracking-wider">Valorização Total (CMP)</div>
            <div className="text-lg font-mono font-semibold text-[#c5a47e] mt-0.5">
              {formatCurrency(totalStockValue)}
            </div>
          </div>
          <div className="bg-[#0f0f0f] border border-[#262626] rounded-lg p-3">
            <div className="text-[11px] text-neutral-400 uppercase tracking-wider">Unidades em Stock</div>
            <div className="text-lg font-mono font-semibold text-emerald-400 mt-0.5">
              {totalStockUnits.toLocaleString()} un
            </div>
          </div>
          <div className="bg-[#0f0f0f] border border-[#262626] rounded-lg p-3">
            <div className="text-[11px] text-neutral-400 uppercase tracking-wider">Artigos no Catálogo</div>
            <div className="text-lg font-mono font-semibold text-neutral-200 mt-0.5">
              {products.length} referências
            </div>
          </div>
          <div className="bg-[#0f0f0f] border border-[#262626] rounded-lg p-3">
            <div className="text-[11px] text-rose-400 uppercase tracking-wider flex items-center justify-between">
              <span>Stock Crítico / Baixo</span>
              {lowStockProducts.length > 0 && <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />}
            </div>
            <div className="text-lg font-mono font-semibold text-rose-400 mt-0.5">
              {lowStockProducts.length} artigos
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-[#121212] border-b border-[#262626] px-6 flex items-center space-x-2 overflow-x-auto">
        {[
          { id: 'overview', label: 'Artigos & Catálogo', icon: Package, count: products.length },
          { id: 'categories', label: 'Gestão de Categorias', icon: Layers, count: categories.length },
          { id: 'warehouses', label: 'Armazéns & Lojas', icon: WarehouseIcon, count: warehouses.length },
          { id: 'lots', label: 'Lotes & Validades', icon: Tag, count: lots.length },
          { id: 'movements', label: 'Histórico de Movimentos', icon: ArrowUpDown, count: stockMovements.length },
          { id: 'inventory_extract', label: 'Extrato de Inventário', icon: FileSpreadsheet },
          {
            id: 'transfer',
            label: 'Transferências entre Lojas',
            icon: RefreshCw,
            count: (stockTransfers?.filter((t) => t.status === 'PENDENTE' || t.status === 'APROVADO').length || 0) > 0
              ? (stockTransfers?.filter((t) => t.status === 'PENDENTE' || t.status === 'APROVADO').length || 0)
              : undefined,
          },
          { id: 'inventory_count', label: 'Contagem Física', icon: FileSpreadsheet },
          { id: 'reorder', label: 'Reposição Automática', icon: AlertTriangle, count: lowStockProducts.length },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-3 text-xs font-medium border-b-2 flex items-center space-x-2 whitespace-nowrap transition-colors cursor-pointer ${
                isActive
                  ? 'border-[#c5a47e] text-[#c5a47e]'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                  isActive
                    ? 'bg-[#c5a47e]/20 text-[#c5a47e]'
                    : 'bg-[#1f1f1f] text-neutral-400'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Content Container */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* TAB 1: OVERVIEW & PRODUCTS CRUD */}
        {activeTab === 'overview' && (
          <div className="space-y-4">
            {/* Filter controls */}
            <div className="space-y-3 bg-[#141414] p-3.5 rounded-xl border border-[#262626]">
              {/* Main Row: Search, Category, and Location */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="relative flex-1 w-full">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Pesquisar por nome, SKU, código de barras..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md pl-9 pr-3 py-1.5 text-xs text-neutral-200 focus:outline-hidden focus:border-[#c5a47e]"
                  />
                </div>

                <div className="flex items-center space-x-2 w-full sm:w-auto">
                  <div className="flex items-center space-x-1">
                    <select
                      value={selectedCategoryFilter}
                      onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                      className="bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-1.5 text-xs text-neutral-200 focus:outline-hidden"
                    >
                      <option value="all">Todas as Categorias</option>
                      {categories.map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => setShowCategoryModal(true)}
                      className="p-1.5 bg-[#1a1a1a] hover:bg-[#252525] text-amber-400 hover:text-amber-300 border border-[#2e2e2e] hover:border-amber-500/40 rounded-md transition-colors cursor-pointer"
                      title="Gerir Categorias (+ Nova / Editar)"
                    >
                      <Layers className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <select
                    value={selectedWarehouseFilter}
                    onChange={(e) => setSelectedWarehouseFilter(e.target.value)}
                    className="bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-1.5 text-xs text-neutral-200 focus:outline-hidden"
                  >
                    <option value="all">Todos os Armazéns / Lojas</option>
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>{w.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Second Row: Consulta de Stock Atual vs. Dias Passados & Filtro de Stock Disponível no Local Selecionado */}
              <div className="pt-2.5 border-t border-[#262626] flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                {/* 1. Consulta de Stock Atual vs. Dias Passados */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#c5a47e]" />
                    Consulta de Stock:
                  </span>
                  <div className="inline-flex rounded-lg p-0.5 bg-[#0d0d0d] border border-[#262626]">
                    <button
                      type="button"
                      onClick={() => setStockDateMode('current')}
                      className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                        stockDateMode === 'current'
                          ? 'bg-[#c5a47e] text-neutral-950 shadow-xs'
                          : 'text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${stockDateMode === 'current' ? 'bg-neutral-950' : 'bg-emerald-500'}`} />
                      Stock Atual (Tempo Real)
                    </button>
                    <button
                      type="button"
                      onClick={() => setStockDateMode('historical')}
                      className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
                        stockDateMode === 'historical'
                          ? 'bg-amber-500 text-neutral-950 shadow-xs'
                          : 'text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      <History className="w-3 h-3" />
                      Stock em Dias Passados
                    </button>
                  </div>

                  {stockDateMode === 'historical' && (
                    <div className="flex items-center gap-1.5 bg-[#0d0d0d] border border-amber-500/40 rounded-lg px-2.5 py-1 animate-fadeIn">
                      <Calendar className="w-3.5 h-3.5 text-amber-400" />
                      <input
                        type="date"
                        max={new Date().toISOString().slice(0, 10)}
                        value={historicalDate}
                        onChange={(e) => setHistoricalDate(e.target.value)}
                        className="bg-transparent text-xs text-amber-300 font-mono focus:outline-hidden cursor-pointer"
                      />
                      <span className="text-[10px] text-neutral-500 font-mono">às 23:59</span>
                    </div>
                  )}
                </div>

                {/* 2. Filtro de Stock Disponível no Local Selecionado */}
                <div className="flex items-center">
                  <label
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                      onlyWithStockInSelectedWarehouse
                        ? 'bg-[#c5a47e]/15 border-[#c5a47e]/50 text-[#c5a47e]'
                        : 'bg-[#0d0d0d] border-[#262626] text-neutral-400 hover:text-neutral-300'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={onlyWithStockInSelectedWarehouse}
                      onChange={(e) => setOnlyWithStockInSelectedWarehouse(e.target.checked)}
                      className="rounded border-[#333] text-[#c5a47e] focus:ring-0 focus:ring-offset-0 bg-[#1a1a1a] cursor-pointer"
                    />
                    <Filter className="w-3.5 h-3.5" />
                    <span>
                      {selectedWarehouseFilter !== 'all'
                        ? `Apenas com stock disponível em "${selectedWarehouseName}"`
                        : 'Apenas artigos com stock disponível (> 0)'}
                    </span>
                    {onlyWithStockInSelectedWarehouse && (
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#c5a47e]/20 text-[#c5a47e] font-semibold">
                        Ativo
                      </span>
                    )}
                  </label>
                </div>
              </div>
            </div>

            {/* Historical Mode Alert Banner */}
            {stockDateMode === 'historical' && (
              <div className="flex items-center justify-between px-4 py-2.5 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-xs">
                <div className="flex items-center gap-2">
                  <Info className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    <strong>Modo de Consulta Histórica Ativo:</strong> A visualizar a posição de stock reconstituída a <strong>{historicalDate} às 23:59</strong> {selectedWarehouseFilter !== 'all' ? `no armazém "${selectedWarehouseName}"` : 'em todos os armazéns'}. As quantidades e valorizações refletem essa data.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setStockDateMode('current')}
                  className="ml-3 px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-md text-[11px] font-medium transition-colors whitespace-nowrap cursor-pointer"
                >
                  Voltar ao Stock Atual
                </button>
              </div>
            )}

            {/* Products Table */}
            <div className="bg-[#141414] border border-[#262626] rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs text-neutral-300">
                <thead className="bg-[#1a1a1a] text-neutral-400 font-medium uppercase tracking-wider text-[10px] border-b border-[#262626]">
                  <tr>
                    <th className="px-4 py-3">Artigo / Referência</th>
                    <th className="px-4 py-3">Categoria</th>
                    <th className="px-4 py-3 text-right">PVP (c/ IVA)</th>
                    <th className="px-4 py-3 text-right">Custo (CMP)</th>
                    <th className="px-4 py-3 text-center">IVA</th>
                    <th className="px-4 py-3 text-right">
                      <div className="flex flex-col items-end">
                        <span>
                          {selectedWarehouseFilter !== 'all'
                            ? `Stock em ${selectedWarehouseName}`
                            : 'Stock Global'}
                        </span>
                        <span className="text-[9px] font-normal text-amber-400 font-mono tracking-normal normal-case">
                          {stockDateMode === 'historical' ? `(em ${historicalDate} 23:59)` : '(Tempo Real)'}
                        </span>
                      </div>
                    </th>
                    <th className="px-4 py-3 text-center">Estado</th>
                    <th className="px-4 py-3 text-right">Ações CRUD</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#262626]">
                  {filteredProducts.map((prod) => {
                    const totalQty = calculateProductStock(prod.id, selectedWarehouseFilter, stockDateMode, historicalDate);
                    const isLow = totalQty <= prod.minStock;
                    const cat = categories.find((c) => c.id === prod.category);

                    return (
                      <tr key={prod.id} className="hover:bg-[#191919] transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-3">
                            {prod.imageUrl ? (
                              <img src={prod.imageUrl} alt="" className="w-9 h-9 rounded-md object-cover bg-neutral-900 border border-[#262626]" />
                            ) : (
                              <div className="w-9 h-9 rounded-md bg-neutral-900 border border-[#262626] flex items-center justify-center text-neutral-500">
                                <Package className="w-4 h-4" />
                              </div>
                            )}
                            <div>
                              <div className="font-medium text-neutral-200">{prod.name}</div>
                              <div className="text-[11px] font-mono text-neutral-500 flex items-center space-x-2">
                                <span>SKU: {prod.sku}</span>
                                <span>&bull;</span>
                                <span>EAN: {prod.barcode}</span>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 rounded-md text-[11px] bg-neutral-800 text-neutral-300 border border-neutral-700">
                            {cat?.name || prod.category}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-semibold text-[#c5a47e]">
                          {formatCurrency(prod.price)}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-neutral-400">
                          {formatCurrency(prod.costPrice)}
                        </td>
                        <td className="px-4 py-3 text-center font-mono">
                          <span
                            className={`px-2 py-0.5 rounded text-[11px] font-bold border ${
                              prod.taxRate === 0
                                ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                                : prod.taxRate === 16
                                ? 'bg-[#c5a47e]/15 text-[#c5a47e] border-[#c5a47e]/30'
                                : 'bg-neutral-800 text-neutral-300 border-neutral-700'
                            }`}
                            title={`Taxa de IVA: ${prod.taxRate}%`}
                          >
                            {prod.taxRate}%
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-semibold">
                          <div className="flex flex-col items-end">
                            <span className={isLow ? 'text-rose-400 font-bold' : 'text-neutral-200'}>
                              {totalQty} {prod.unit}
                            </span>
                            <span className="text-[10px] text-neutral-500 font-normal">
                              {stockDateMode === 'historical' ? (
                                <span className="text-amber-400/90 font-mono">Posição Reconstituída</span>
                              ) : (
                                `Min: ${prod.minStock} / Max: ${prod.maxStock}`
                              )}
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center">
                          {isLow ? (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-rose-500/10 text-rose-400 border border-rose-500/30">
                              Crítico
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              Normal
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end space-x-1">
                            {canCreate && (
                              <button
                                onClick={() => {
                                  setProdutoSelecionado(prod.id);
                                  setArmazemSelecionado(
                                    selectedWarehouseFilter !== 'all'
                                      ? selectedWarehouseFilter
                                      : (currentStore.defaultWarehouseId || warehouses[0]?.id || '')
                                  );
                                  setQuantidadeStock(1);
                                  setShowAddStockModal(true);
                                }}
                                title="Adicionar Stock a este Artigo (Supabase)"
                                className="p-1.5 hover:bg-neutral-800 rounded-md text-emerald-400 transition-colors cursor-pointer"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              onClick={() => handleOpenAdjustStock(prod)}
                              title="Ajustar Stock Manualmente"
                              className="p-1.5 hover:bg-neutral-800 rounded-md text-amber-400 transition-colors cursor-pointer"
                            >
                              <Sliders className="w-3.5 h-3.5" />
                            </button>
                            {canEdit && (
                              <button
                                onClick={() => handleOpenEditProduct(prod)}
                                title="Editar Artigo"
                                className="p-1.5 hover:bg-neutral-800 rounded-md text-cyan-400 transition-colors cursor-pointer"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                            {canDelete && (
                              <button
                                onClick={() => {
                                  requestConfirm({
                                    title: 'Eliminar Artigo do Catálogo',
                                    message: `Tem a certeza que deseja eliminar o artigo "${prod.name}" (${prod.sku})? Esta ação removerá o registo de stock associado.`,
                                    itemDetails: `SKU: ${prod.sku} | Preço: ${formatCurrency(prod.price)} | Categoria: ${prod.category}`,
                                    confirmLabel: 'Eliminar Artigo',
                                    isDestructive: true,
                                    onConfirm: () => {
                                      deleteProduct(prod.id);
                                    },
                                  });
                                }}
                                title="Eliminar Artigo"
                                className="p-1.5 hover:bg-neutral-800 rounded-md text-rose-400 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredProducts.length === 0 && (
                    <tr>
                      <td colSpan={8} className="px-4 py-12 text-center text-neutral-500">
                        <div className="flex flex-col items-center justify-center space-y-2">
                          <Package className="w-8 h-8 text-neutral-600" />
                          <div className="text-sm font-medium text-neutral-400">Nenhum artigo encontrado</div>
                          <div className="text-xs text-neutral-500 max-w-md">
                            {onlyWithStockInSelectedWarehouse
                              ? `Não foram encontrados artigos com stock positivo (> 0) ${selectedWarehouseFilter !== 'all' ? `no armazém "${selectedWarehouseName}"` : 'em stock global'}${stockDateMode === 'historical' ? ` na data ${historicalDate}` : ''}.`
                              : 'Não existem artigos correspondentes aos critérios de pesquisa e filtros selecionados.'}
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB: CATEGORIES CRUD */}
        {activeTab === 'categories' && (
          <CategoryManagementTab
            onFilterByCategory={(catId) => {
              setSelectedCategoryFilter(catId);
              setActiveTab('overview');
            }}
          />
        )}

        {/* TAB 2: WAREHOUSES CRUD */}
        {activeTab === 'warehouses' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {warehouses.map((wh) => {
                const whStock = stock.filter((s) => s.warehouseId === wh.id);
                const whUnits = whStock.reduce((sum, s) => sum + s.quantity, 0);
                const whVal = whStock.reduce((sum, s) => sum + s.quantity * s.avgCost, 0);

                return (
                  <div key={wh.id} className="bg-[#141414] border border-[#262626] rounded-xl p-5 relative group hover:border-[#383838] transition-all">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                          <WarehouseIcon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-neutral-200 text-sm">{wh.name}</h3>
                          <span className="text-xs font-mono text-neutral-500">{wh.code}</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-1">
                        {canEdit && (
                          <button
                            onClick={() => {
                              setEditingWarehouse(wh);
                              setWhForm({
                                name: wh.name,
                                code: wh.code,
                                location: wh.location,
                                isDefault: !!wh.isDefault,
                                storeId: wh.storeId || currentStore.id,
                              });
                            }}
                            className="p-1.5 hover:bg-neutral-800 rounded-md text-cyan-400 cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {canDelete && (
                          <button
                            onClick={() => {
                              requestConfirm({
                                title: 'Eliminar Armazém',
                                message: `Tem a certeza que deseja eliminar o armazém "${wh.name}" (${wh.code})?`,
                                itemDetails: `Código: ${wh.code} | Localização: ${wh.location || 'N/A'}`,
                                confirmLabel: 'Eliminar Armazém',
                                isDestructive: true,
                                onConfirm: () => {
                                  deleteWarehouse(wh.id);
                                },
                              });
                            }}
                            className="p-1.5 hover:bg-neutral-800 rounded-md text-rose-400 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#262626] space-y-1.5 text-xs text-neutral-400">
                      <div className="flex justify-between">
                        <span>Localização:</span>
                        <span className="text-neutral-200 font-medium">{wh.location || 'N/D'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total de Unidades:</span>
                        <span className="text-emerald-400 font-mono font-medium">{whUnits.toLocaleString()} un</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Valor em Stock:</span>
                        <span className="text-[#c5a47e] font-mono font-semibold">{formatCurrency(whVal)}</span>
                      </div>
                      <div className="flex justify-between items-center pt-1">
                        <span>Armazém Principal:</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                          wh.isDefault ? 'bg-emerald-500/20 text-emerald-400' : 'bg-neutral-800 text-neutral-400'
                        }`}>
                          {wh.isDefault ? 'Padrão' : 'Secundário'}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: LOTS & BATCHES CRUD */}
        {activeTab === 'lots' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-[#141414] p-3 rounded-lg border border-[#262626]">
              <div className="text-xs text-neutral-400">
                Rastreabilidade de lotes com controlo de datas de fabrico e validade
              </div>
              {canCreate && (
                <button
                  onClick={() => {
                    setEditingLot(null);
                    setShowNewLotModal(true);
                  }}
                  className="px-3 py-1.5 bg-[#c5a47e] text-neutral-950 rounded-md text-xs font-medium cursor-pointer"
                >
                  + Criar Novo Lote
                </button>
              )}
            </div>

            <div className="bg-[#141414] border border-[#262626] rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs text-neutral-300">
                <thead className="bg-[#1a1a1a] text-neutral-400 font-medium uppercase tracking-wider text-[10px] border-b border-[#262626]">
                  <tr>
                    <th className="px-4 py-3">Número de Lote</th>
                    <th className="px-4 py-3">Artigo</th>
                    <th className="px-4 py-3">Armazém</th>
                    <th className="px-4 py-3">Fabrico</th>
                    <th className="px-4 py-3">Validade</th>
                    <th className="px-4 py-3 text-right">Qtd. Inicial</th>
                    <th className="px-4 py-3 text-right">Qtd. Atual</th>
                    <th className="px-4 py-3 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#262626]">
                  {lots.map((lot) => {
                    const prod = products.find((p) => p.id === lot.productId);
                    const wh = warehouses.find((w) => w.id === lot.warehouseId);
                    const isNearExpiry = new Date(lot.expiryDate).getTime() - Date.now() < 90 * 86400000;

                    return (
                      <tr key={lot.id} className="hover:bg-[#191919] transition-colors">
                        <td className="px-4 py-3 font-mono font-semibold text-[#c5a47e]">{lot.batchNumber}</td>
                        <td className="px-4 py-3 font-medium text-neutral-200">{prod?.name || lot.productId}</td>
                        <td className="px-4 py-3 text-neutral-400">{wh?.name || lot.warehouseId}</td>
                        <td className="px-4 py-3 font-mono text-neutral-400">{formatDate(lot.manufacturingDate)}</td>
                        <td className="px-4 py-3 font-mono">
                          <span className={isNearExpiry ? 'text-rose-400 font-bold' : 'text-neutral-300'}>
                            {formatDate(lot.expiryDate)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right font-mono">{lot.initialQuantity}</td>
                        <td className="px-4 py-3 text-right font-mono font-semibold text-emerald-400">{lot.currentQuantity}</td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end space-x-1">
                            {canEdit && (
                              <button
                                onClick={() => {
                                  setEditingLot(lot);
                                  setLotForm({
                                    productId: lot.productId,
                                    warehouseId: lot.warehouseId,
                                    batchNumber: lot.batchNumber,
                                    manufacturingDate: lot.manufacturingDate,
                                    expiryDate: lot.expiryDate,
                                    initialQuantity: lot.initialQuantity,
                                    currentQuantity: lot.currentQuantity,
                                    supplierId: lot.supplierId || '',
                                  });
                                }}
                                className="p-1.5 hover:bg-neutral-800 rounded-md text-cyan-400 cursor-pointer"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                            {canDelete && (
                              <button
                                onClick={() => {
                                  requestConfirm({
                                    title: 'Eliminar Lote de Stock',
                                    message: `Tem a certeza que deseja eliminar o lote "${lot.batchNumber}"?`,
                                    itemDetails: `Lote: ${lot.batchNumber} | Quantidade: ${lot.currentQuantity} | Validade: ${lot.expiryDate}`,
                                    confirmLabel: 'Eliminar Lote',
                                    isDestructive: true,
                                    onConfirm: () => {
                                      deleteLot(lot.id);
                                    },
                                  });
                                }}
                                className="p-1.5 hover:bg-neutral-800 rounded-md text-rose-400 cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: MOVEMENTS LOG CRUD */}
        {activeTab === 'movements' && (
          <div className="space-y-4">
            {/* Header / Filter Toolbar */}
            <div className="bg-[#141414] border border-[#262626] rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
              <div className="flex flex-1 items-center gap-3 w-full md:w-auto">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
                  <input
                    type="text"
                    value={movementSearch}
                    onChange={(e) => setMovementSearch(e.target.value)}
                    placeholder="Pesquisar por artigo, doc ref, motivo, SKU..."
                    className="w-full bg-[#1e1e1e] border border-[#333] rounded-lg pl-9 pr-3 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-[#c5a47e]"
                  />
                  {movementSearch && (
                    <button
                      onClick={() => setMovementSearch('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Type Filter Pills */}
              <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
                {(
                  [
                    { id: 'all', label: 'Todos' },
                    { id: 'entrada', label: 'Entradas' },
                    { id: 'saida', label: 'Saídas' },
                    { id: 'transferencia', label: 'Transf.' },
                    { id: 'ajuste', label: 'Ajustes' },
                    { id: 'devolucao', label: 'Devoluções' },
                  ] as const
                ).map((t) => {
                  const isActive = movementTypeFilter === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setMovementTypeFilter(t.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                        isActive
                          ? 'bg-[#c5a47e] text-neutral-950 font-semibold shadow-sm'
                          : 'bg-[#1e1e1e] text-neutral-400 hover:text-neutral-200 border border-[#2a2a2a]'
                      }`}
                    >
                      {t.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Movements Table */}
            <div className="bg-[#141414] border border-[#262626] rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs text-neutral-300">
                <thead className="bg-[#1a1a1a] text-neutral-400 font-medium uppercase tracking-wider text-[10px] border-b border-[#262626]">
                  <tr>
                    <th className="px-4 py-3">Data e Hora Exata</th>
                    <th className="px-4 py-3">Tipo</th>
                    <th className="px-4 py-3">Artigo</th>
                    <th className="px-4 py-3">Origem &rarr; Destino</th>
                    <th className="px-4 py-3 text-right">Quantidade</th>
                    <th className="px-4 py-3">Documento Ref.</th>
                    <th className="px-4 py-3">Motivo</th>
                    <th className="px-4 py-3 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#262626]">
                  {filteredAndSortedMovements.map((mov) => {
                    const prod = products.find((p) => p.id === mov.productId);
                    const fromWh = warehouses.find((w) => w.id === mov.originWarehouseId);
                    const toWh = warehouses.find((w) => w.id === mov.targetWarehouseId);
                    const exactTs = mov.resolvedExactTimestamp;

                    return (
                      <tr key={mov.id} className="hover:bg-[#191919] transition-colors">
                        <td
                          className="px-4 py-3 whitespace-nowrap font-mono"
                          title={`Data e Hora Exata: ${formatExactDateTime(exactTs, true)} (Timestamp: ${exactTs || '—'})`}
                        >
                          <div className="flex flex-col leading-tight">
                            <span className="text-neutral-200 font-semibold text-xs">
                              {formatExactDate(exactTs)}
                            </span>
                            <span className="text-neutral-400 text-[10px] flex items-center space-x-1 mt-0.5">
                              <Clock className="w-2.5 h-2.5 text-[#c5a47e] shrink-0" />
                              <span>{formatExactTime(exactTs, true)}</span>
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-medium uppercase ${
                              mov.type === 'entrada'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                : mov.type === 'saida'
                                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                                : mov.type === 'transferencia'
                                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                                : mov.type === 'devolucao'
                                ? 'bg-purple-500/10 text-purple-400 border border-purple-500/30'
                                : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                            }`}
                          >
                            {mov.type}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium text-neutral-200">{prod?.name || mov.productId}</div>
                          {prod?.sku && (
                            <div className="text-[10px] font-mono text-neutral-500">SKU: {prod.sku}</div>
                          )}
                        </td>
                        <td className="px-4 py-3 text-neutral-400">
                          {fromWh?.name || '—'} &rarr; {toWh?.name || '—'}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-semibold text-neutral-200">
                          <span
                            className={
                              mov.type === 'saida'
                                ? 'text-rose-400'
                                : mov.type === 'entrada' || mov.type === 'devolucao'
                                ? 'text-emerald-400'
                                : 'text-neutral-200'
                            }
                          >
                            {mov.type === 'saida' ? '-' : mov.type === 'entrada' ? '+' : ''}
                            {mov.quantity}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono text-neutral-300">
                          {mov.referenceDoc ? (
                            <span className="bg-[#1e1e1e] px-1.5 py-0.5 rounded border border-[#333] text-[11px]">
                              {mov.referenceDoc}
                            </span>
                          ) : (
                            <span className="text-neutral-500">—</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-neutral-400 max-w-xs truncate" title={mov.reason}>
                          {mov.reason || '—'}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {canDelete && (
                            <button
                              onClick={() => deleteStockMovement(mov.id)}
                              className="p-1 hover:bg-neutral-800 rounded-md text-neutral-500 hover:text-rose-400 cursor-pointer"
                              title="Remover registo"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  {filteredAndSortedMovements.length === 0 && (
                    <tr>
                      <td colSpan={8} className="text-center py-10 text-neutral-500">
                        {stockMovements.length === 0
                          ? 'Nenhum movimento de stock registado ainda.'
                          : 'Nenhum movimento encontrado para os filtros selecionados.'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB: INVENTORY EXTRACT (Extrato de Inventário Filtrado) */}
        {activeTab === 'inventory_extract' && (
          <InventoryExtractTab />
        )}

        {/* TAB 5: STOCK TRANSFER (Transferências com Código de Verificação e Autorização) */}
        {activeTab === 'transfer' && (
          <div className="space-y-6">
            <InterStoreTransfersTab />
          </div>
        )}

        {/* TAB 6: PHYSICAL INVENTORY COUNT */}
        {activeTab === 'inventory_count' && (
          <PhysicalInventoryCountTab />
        )}

        {/* TAB 7: REORDER & LOW STOCK */}
        {activeTab === 'reorder' && (
          <div className="space-y-4">
            <div className="bg-[#141414] p-4 rounded-xl border border-[#262626] flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-rose-400">Sugestões de Reposição Crítica</h3>
                <p className="text-xs text-neutral-400">
                  Artigos cujo stock atual está abaixo do limite de segurança configurado.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {lowStockProducts.map((prod) => {
                const currentQty = stock.filter((s) => s.productId === prod.id).reduce((sum, s) => sum + s.quantity, 0);
                const needed = prod.maxStock - currentQty;

                return (
                  <div key={prod.id} className="bg-[#141414] border border-rose-500/20 rounded-xl p-4 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold text-neutral-200 text-sm">{prod.name}</h4>
                          <span className="text-xs font-mono text-neutral-500">{prod.sku}</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-rose-500/20 text-rose-400 font-mono">
                          Stock: {currentQty} / Min: {prod.minStock}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#262626] flex items-center justify-between">
                      <div className="text-xs text-neutral-400">
                        Sugerido encomendar: <strong className="text-neutral-200 font-mono">{needed} un</strong> ({formatCurrency(needed * prod.costPrice)})
                      </div>
                      <button
                        onClick={() => handleCreateRequisitionForLowStock(prod)}
                        className="px-3 py-1.5 bg-[#c5a47e] hover:bg-[#b5946e] text-neutral-950 font-medium text-xs rounded-md transition-colors cursor-pointer"
                      >
                        Gerar Requisição
                      </button>
                    </div>
                  </div>
                );
              })}
              {lowStockProducts.length === 0 && (
                <div className="col-span-2 text-center py-12 text-neutral-500 bg-[#141414] rounded-xl border border-[#262626]">
                  <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
                  <p>Todos os artigos encontram-se dentro dos níveis de stock adequados.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ================= MODAL: CREATE / EDIT PRODUCT ================= */}
      {(showNewProductModal || editingProduct) && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#141414] border border-[#262626] rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-150">
            <div className="px-6 py-4 border-b border-[#262626] flex items-center justify-between bg-[#191919]">
              <h3 className="font-serif text-base text-[#e5e5e5]">
                {editingProduct ? 'Editar Artigo' : 'Adicionar Novo Artigo'}
              </h3>
              <button
                onClick={() => {
                  setShowNewProductModal(false);
                  setEditingProduct(null);
                }}
                className="p-1 hover:bg-neutral-800 rounded-md text-neutral-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Nome do Artigo *</label>
                  <input
                    type="text"
                    required
                    value={prodForm.name}
                    onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden focus:border-[#c5a47e]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Código SKU *</label>
                  <input
                    type="text"
                    required
                    value={prodForm.sku}
                    onChange={(e) => setProdForm({ ...prodForm, sku: e.target.value })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden focus:border-[#c5a47e]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Código de Barras (EAN-13)</label>
                  <input
                    type="text"
                    value={prodForm.barcode}
                    onChange={(e) => setProdForm({ ...prodForm, barcode: e.target.value })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden focus:border-[#c5a47e]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Preço de Venda (PVP c/ IVA - {currencySymbol}) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={prodForm.price}
                    onChange={(e) => setProdForm({ ...prodForm, price: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden focus:border-[#c5a47e]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Preço de Custo (CMP - {currencySymbol}) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={prodForm.costPrice}
                    onChange={(e) => setProdForm({ ...prodForm, costPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden focus:border-[#c5a47e]"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-neutral-300">Taxa de IVA *</label>
                    <span className="text-[11px] text-[#c5a47e] font-mono font-bold">
                      {prodForm.taxRate}%
                    </span>
                  </div>
                  <div className="flex space-x-2">
                    <select
                      value={prodForm.taxRate}
                      onChange={(e) => setProdForm({ ...prodForm, taxRate: Number(e.target.value) })}
                      className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden focus:border-[#c5a47e]"
                    >
                      {companyVatRates.map((vr) => (
                        <option key={vr.id} value={vr.rate}>
                          {vr.name} ({vr.rate}%) {vr.isDefault ? '— Padrão' : ''}
                        </option>
                      ))}
                      {!companyVatRates.some((vr) => vr.rate === prodForm.taxRate) && (
                        <option value={prodForm.taxRate}>Personalizada ({prodForm.taxRate}%)</option>
                      )}
                    </select>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.5"
                      placeholder="%"
                      value={prodForm.taxRate}
                      onChange={(e) => setProdForm({ ...prodForm, taxRate: Math.max(0, Math.min(100, parseFloat(e.target.value) || 0)) })}
                      className="w-20 bg-[#0d0d0d] border border-[#262626] rounded-md px-2 py-2 text-xs text-[#c5a47e] font-mono font-bold text-center focus:outline-hidden focus:border-[#c5a47e]"
                      title="Digitar taxa de IVA personalizada (%)"
                    />
                  </div>
                </div>

                {/* Live Tax & Price Breakdown Box */}
                <div className="col-span-2 p-3 bg-[#0a0a0a] border border-[#262626] rounded-lg text-xs grid grid-cols-3 gap-2 text-center">
                  <div>
                    <span className="text-[10px] text-neutral-500 block uppercase font-medium">Preço Base (s/ IVA)</span>
                    <span className="font-mono font-semibold text-neutral-300">
                      {formatCurrency(prodForm.price / (1 + (prodForm.taxRate / 100)))}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-500 block uppercase font-medium">IVA ({prodForm.taxRate}%)</span>
                    <span className="font-mono font-bold text-[#c5a47e]">
                      {formatCurrency(prodForm.price - (prodForm.price / (1 + (prodForm.taxRate / 100))))}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-500 block uppercase font-medium">PVP Final (c/ IVA)</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {formatCurrency(prodForm.price)}
                    </span>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-neutral-300">Categoria</label>
                    <button
                      type="button"
                      onClick={() => setShowCategoryModal(true)}
                      className="text-[11px] text-[#c5a47e] hover:underline flex items-center space-x-1 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Gerir</span>
                    </button>
                  </div>
                  <select
                    value={prodForm.category}
                    onChange={(e) => setProdForm({ ...prodForm, category: e.target.value })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Stock Mínimo</label>
                  <input
                    type="number"
                    value={prodForm.minStock}
                    onChange={(e) => setProdForm({ ...prodForm, minStock: parseInt(e.target.value) || 0 })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Stock Máximo</label>
                  <input
                    type="number"
                    value={prodForm.maxStock}
                    onChange={(e) => setProdForm({ ...prodForm, maxStock: parseInt(e.target.value) || 0 })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-medium text-neutral-300 mb-1">URL da Imagem</label>
                  <input
                    type="text"
                    value={prodForm.imageUrl}
                    onChange={(e) => setProdForm({ ...prodForm, imageUrl: e.target.value })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-[#262626] flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowNewProductModal(false);
                    setEditingProduct(null);
                  }}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg text-xs font-medium cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#c5a47e] hover:bg-[#b5946e] text-neutral-950 font-medium text-xs rounded-lg transition-colors cursor-pointer"
                >
                  {editingProduct ? 'Guardar Alterações' : 'Criar Artigo'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADICIONAR STOCK (SUPABASE) ================= */}
      {showAddStockModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#141414] border border-[#262626] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-[#262626] flex items-center justify-between bg-[#191919]">
              <div className="flex items-center space-x-2">
                <Boxes className="w-5 h-5 text-emerald-400" />
                <h3 className="font-serif text-base text-[#e5e5e5]">Adicionar Stock (Supabase)</h3>
              </div>
              <button
                onClick={() => setShowAddStockModal(false)}
                className="p-1 hover:bg-neutral-800 rounded-md text-neutral-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Artigo a Selecionar *
                </label>
                <select
                  value={produtoSelecionado}
                  onChange={(e) => setProdutoSelecionado(e.target.value)}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden focus:border-[#c5a47e]"
                >
                  <option value="">-- Selecionar Artigo --</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} {p.sku ? `(SKU: ${p.sku})` : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Armazém de Destino *
                </label>
                <select
                  value={armazemSelecionado}
                  onChange={(e) => setArmazemSelecionado(e.target.value)}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden focus:border-[#c5a47e]"
                >
                  <option value="">-- Selecionar Armazém --</option>
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Quantidade a Adicionar
                </label>
                <input
                  type="number"
                  min="1"
                  step="1"
                  value={quantidadeStock}
                  onChange={(e) => setQuantidadeStock(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden focus:border-[#c5a47e]"
                />
              </div>

              <div className="pt-4 border-t border-[#262626] flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowAddStockModal(false)}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg text-xs font-medium cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  id="btn-confirmar-adicionar-stock"
                  type="button"
                  disabled={isSubmittingStock || !produtoSelecionado || !armazemSelecionado}
                  onClick={handleAdicionarStock}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow-sm cursor-pointer"
                >
                  {isSubmittingStock ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>A gravar no Supabase...</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Confirmar e Adicionar Stock</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADJUST STOCK ================= */}
      {adjustingProduct && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#141414] border border-[#262626] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-[#262626] flex items-center justify-between bg-[#191919]">
              <h3 className="font-serif text-base text-[#e5e5e5]">Ajustar Stock Manual</h3>
              <button onClick={() => setAdjustingProduct(null)} className="p-1 hover:bg-neutral-800 rounded-md text-neutral-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAdjustment} className="p-6 space-y-4">
              <div>
                <span className="text-xs text-neutral-400">Artigo Selecionado:</span>
                <div className="text-sm font-semibold text-neutral-200 mt-0.5">{adjustingProduct.name}</div>
                <div className="text-xs font-mono text-neutral-500">SKU: {adjustingProduct.sku}</div>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Armazém</label>
                <select
                  value={adjustWarehouseId}
                  onChange={(e) => setAdjustWarehouseId(e.target.value)}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden"
                >
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Nova Quantidade Real em Stock</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={adjustNewQty}
                  onChange={(e) => setAdjustNewQty(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Motivo do Acerto</label>
                <input
                  type="text"
                  required
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden"
                />
              </div>

              <div className="pt-4 border-t border-[#262626] flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setAdjustingProduct(null)}
                  className="px-4 py-2 bg-neutral-800 text-neutral-300 rounded-lg text-xs font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#c5a47e] text-neutral-950 font-medium text-xs rounded-lg cursor-pointer"
                >
                  Gravar Ajuste
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE / EDIT WAREHOUSE ================= */}
      {(showNewWarehouseModal || editingWarehouse) && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#141414] border border-[#262626] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-[#262626] flex items-center justify-between bg-[#191919]">
              <h3 className="font-serif text-base text-[#e5e5e5]">
                {editingWarehouse ? 'Editar Armazém' : 'Novo Armazém'}
              </h3>
              <button
                onClick={() => {
                  setShowNewWarehouseModal(false);
                  setEditingWarehouse(null);
                }}
                className="p-1 hover:bg-neutral-800 rounded-md text-neutral-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveWarehouse} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Nome do Armazém *</label>
                <input
                  type="text"
                  required
                  value={whForm.name}
                  onChange={(e) => setWhForm({ ...whForm, name: e.target.value })}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Código Identificador *</label>
                <input
                  type="text"
                  required
                  value={whForm.code}
                  onChange={(e) => setWhForm({ ...whForm, code: e.target.value.toUpperCase() })}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Localização Física</label>
                <input
                  type="text"
                  value={whForm.location}
                  onChange={(e) => setWhForm({ ...whForm, location: e.target.value })}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <input
                  type="checkbox"
                  id="whDefault"
                  checked={whForm.isDefault}
                  onChange={(e) => setWhForm({ ...whForm, isDefault: e.target.checked })}
                  className="rounded border-neutral-700 text-[#c5a47e]"
                />
                <label htmlFor="whDefault" className="text-xs text-neutral-300 cursor-pointer">
                  Definir como Armazém Principal por Padrão
                </label>
              </div>

              <div className="pt-4 border-t border-[#262626] flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowNewWarehouseModal(false);
                    setEditingWarehouse(null);
                  }}
                  className="px-4 py-2 bg-neutral-800 text-neutral-300 rounded-lg text-xs font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#c5a47e] text-neutral-950 font-medium text-xs rounded-lg cursor-pointer"
                >
                  {editingWarehouse ? 'Guardar' : 'Criar Armazém'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE / EDIT LOT ================= */}
      {(showNewLotModal || editingLot) && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-[#141414] border border-[#262626] rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-[#262626] flex items-center justify-between bg-[#191919]">
              <h3 className="font-serif text-base text-[#e5e5e5]">
                {editingLot ? 'Editar Lote' : 'Novo Lote / Validade'}
              </h3>
              <button
                onClick={() => {
                  setShowNewLotModal(false);
                  setEditingLot(null);
                }}
                className="p-1 hover:bg-neutral-800 rounded-md text-neutral-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveLot} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Artigo *</label>
                <select
                  value={lotForm.productId}
                  onChange={(e) => setLotForm({ ...lotForm, productId: e.target.value })}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>{p.name} ({p.sku})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Armazém</label>
                <select
                  value={lotForm.warehouseId}
                  onChange={(e) => setLotForm({ ...lotForm, warehouseId: e.target.value })}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 focus:outline-hidden"
                >
                  {warehouses.map((w) => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">Número de Lote / Batch *</label>
                <input
                  type="text"
                  required
                  value={lotForm.batchNumber}
                  onChange={(e) => setLotForm({ ...lotForm, batchNumber: e.target.value })}
                  className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Data de Fabrico</label>
                  <input
                    type="date"
                    value={lotForm.manufacturingDate}
                    onChange={(e) => setLotForm({ ...lotForm, manufacturingDate: e.target.value })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Data de Validade</label>
                  <input
                    type="date"
                    value={lotForm.expiryDate}
                    onChange={(e) => setLotForm({ ...lotForm, expiryDate: e.target.value })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Quantidade Inicial</label>
                  <input
                    type="number"
                    min="1"
                    value={lotForm.initialQuantity}
                    onChange={(e) => setLotForm({ ...lotForm, initialQuantity: parseInt(e.target.value) || 0 })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Quantidade Atual</label>
                  <input
                    type="number"
                    min="0"
                    value={lotForm.currentQuantity}
                    onChange={(e) => setLotForm({ ...lotForm, currentQuantity: parseInt(e.target.value) || 0 })}
                    className="w-full bg-[#0d0d0d] border border-[#262626] rounded-md px-3 py-2 text-xs text-neutral-200 font-mono focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-[#262626] flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowNewLotModal(false);
                    setEditingLot(null);
                  }}
                  className="px-4 py-2 bg-neutral-800 text-neutral-300 rounded-lg text-xs font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#c5a47e] text-neutral-950 font-medium text-xs rounded-lg cursor-pointer"
                >
                  {editingLot ? 'Guardar' : 'Criar Lote'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Product Import / Export Modal */}
      <ProductImportExportModal
        isOpen={showImportExportModal}
        onClose={() => setShowImportExportModal(false)}
        initialMode={importExportInitialMode}
      />

      {/* Category Management Modal */}
      <CategoryManagementModal
        isOpen={showCategoryModal}
        onClose={() => setShowCategoryModal(false)}
        onSelectCategory={(catId) => {
          setSelectedCategoryFilter(catId);
          setActiveTab('overview');
        }}
      />

          </div>
  );
};
