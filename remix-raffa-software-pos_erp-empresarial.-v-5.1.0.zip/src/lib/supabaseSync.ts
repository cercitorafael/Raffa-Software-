import { supabase, isValidHttpUrl, DEFAULT_SUPABASE_URL, DEFAULT_SUPABASE_ANON_KEY, UserProfile } from './supabase';
import {
  Product,
  Customer,
  Supplier,
  ProductCategory,
  Sale,
  User,
  Warehouse,
  StockItem,
  AccountPayable,
  AccountReceivable,
  CashShift,
  Company,
  Store,
  Employee,
  EmployeeShift,
  TimeClockEntry,
  PayrollSlip,
  OfflineSyncQueueItem,
} from '../types';
import { offlineDB } from '../utils/indexedDB';
import { isCompanyDeleted } from '../utils/companyDeletion';

export interface SalesGoalRecord {
  id: string;
  companyId?: string;
  company_id?: string;
  anoReferencia?: number;
  ano_referencia?: number;
  metaAnualTotal?: number;
  meta_anual_total?: number;
  estrategia?: string;
  metasMensais?: any[];
  metas_mensais?: any[];
  valoresManuais?: number[];
  valores_manuais?: number[];
  historicoValores?: number[];
  historico_valores?: number[];
  vendasRealizadas?: number[];
  vendas_realizadas?: number[];
  savedAt?: string;
  saved_at?: string;
  source?: string;
  isManuallyEdited?: boolean;
  is_manually_edited?: boolean;
  updatedAt?: string;
  updated_at?: string;
}

export interface SupabaseSyncLog {
  id: string;
  timestamp: string;
  table: string;
  action: 'INSERT' | 'UPDATE' | 'DELETE' | 'PULL' | 'PUSH' | 'ERROR';
  origin: 'SUPABASE_REALTIME' | 'LOCAL_APP';
  description: string;
  status: 'success' | 'error' | 'info';
  data?: any;
}

export type TableSyncName =
  | 'profiles'
  | 'empresas'
  | 'lojas'
  | 'produtos'
  | 'clientes'
  | 'fornecedores'
  | 'categorias'
  | 'vendas'
  | 'usuarios'
  | 'armazens'
  | 'stock'
  | 'contas_pagar'
  | 'contas_receber'
  | 'turnos_caixa'
  | 'colaboradores'
  | 'registos_ponto'
  | 'recibos_salario'
  | 'escalas_trabalho'
  | 'metas_vendas';

export interface RealtimeSyncCallbacks {
  onProfileChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<UserProfile>, rawOld?: any) => void;
  onCompanyChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<Company>, rawOld?: any) => void;
  onStoreChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<Store>, rawOld?: any) => void;
  onProductChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<Product>, rawOld?: any) => void;
  onCustomerChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<Customer>, rawOld?: any) => void;
  onSupplierChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<Supplier>, rawOld?: any) => void;
  onCategoryChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<ProductCategory>, rawOld?: any) => void;
  onSaleChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<Sale>, rawOld?: any) => void;
  onUserChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<User>, rawOld?: any) => void;
  onWarehouseChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<Warehouse>, rawOld?: any) => void;
  onStockChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<StockItem>, rawOld?: any) => void;
  onAccountPayableChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<AccountPayable>, rawOld?: any) => void;
  onAccountReceivableChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<AccountReceivable>, rawOld?: any) => void;
  onShiftChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<CashShift>, rawOld?: any) => void;
  onEmployeeChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<Employee>, rawOld?: any) => void;
  onTimeEntryChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<TimeClockEntry>, rawOld?: any) => void;
  onPayrollChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<PayrollSlip>, rawOld?: any) => void;
  onEmployeeShiftChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<EmployeeShift>, rawOld?: any) => void;
  onSalesGoalChange?: (event: 'INSERT' | 'UPDATE' | 'DELETE', item: Partial<SalesGoalRecord>, rawOld?: any) => void;
  onStatusChange?: (status: 'connected' | 'connecting' | 'disconnected' | 'error', errorMsg?: string) => void;
  onLogAdded?: (log: SupabaseSyncLog) => void;
}

let activeChannel: any = null;
let currentCallbacks: RealtimeSyncCallbacks = {};
let reconnectTimeout: any = null;
let isReconnecting = false;
const syncLogs: SupabaseSyncLog[] = [];
const MAX_LOGS = 150;

// Local pending sync queue for offline / retry support
const PENDING_SYNC_STORAGE_KEY = 'erp_pending_supabase_queue';

// Exponential backoff configuration
export const BASE_RETRY_DELAY_MS = 2000; // 2 seconds initial delay
export const MAX_RETRY_DELAY_MS = 60000; // 60 seconds maximum delay

/**
 * Calculates exponential backoff with random jitter:
 * delay = min(maxMs, baseMs * 2^(min(retryCount, 7))) + jitter(0-1000ms)
 */
export function calculateExponentialBackoff(
  retryCount: number,
  baseMs = BASE_RETRY_DELAY_MS,
  maxMs = MAX_RETRY_DELAY_MS
): number {
  const exponent = Math.min(Math.max(0, retryCount), 7);
  const backoff = baseMs * Math.pow(2, exponent);
  const jitter = Math.floor(Math.random() * 1000);
  return Math.min(backoff + jitter, maxMs);
}

export function isTableMissingError(error: any): boolean {
  if (!error) return false;
  const code = String(error.code || '');
  const msg = String(error.message || '').toLowerCase();
  return (
    code === '42P01' ||
    code === 'PGRST205' ||
    msg.includes('does not exist') ||
    msg.includes('schema cache') ||
    msg.includes('could not find the table') ||
    (msg.includes('relation') && msg.includes('does not exist'))
  );
}

/**
 * Verifica se um erro retornado pelo Supabase decorre de restrições de Row-Level Security (RLS)
 * Código Postgres 42501 ou mensagem de violação de política de segurança.
 */
export function isRlsError(error: any): boolean {
  if (!error) return false;
  const code = String(error.code || '');
  const msg = String(error.message || '').toLowerCase();
  const details = String(error.details || '').toLowerCase();
  return (
    code === '42501' ||
    error.status === 403 ||
    msg.includes('row-level security') ||
    msg.includes('violates row-level security policy') ||
    msg.includes('permission denied') ||
    msg.includes('security policy') ||
    details.includes('row-level security') ||
    details.includes('policy')
  );
}

// Throttle idênticos avisos de erro para prevenir spam no terminal e na interface
const lastLoggedWarnings = new Map<string, number>();

export function throttledWarn(key: string, message: string, detail?: any, throttleMs = 90000): void {
  const now = Date.now();
  const lastTime = lastLoggedWarnings.get(key) || 0;
  if (now - lastTime >= throttleMs) {
    lastLoggedWarnings.set(key, now);
    if (detail !== undefined) {
      console.warn(message, detail);
    } else {
      console.warn(message);
    }
  }
}

interface PendingSyncQueueItem {
  id: string;
  table: TableSyncName;
  action: 'insert' | 'update' | 'upsert' | 'delete';
  record: any;
  timestamp: number;
}

function getPendingQueue(): PendingSyncQueueItem[] {
  try {
    const raw = localStorage.getItem(PENDING_SYNC_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function savePendingQueue(queue: PendingSyncQueueItem[]) {
  try {
    localStorage.setItem(PENDING_SYNC_STORAGE_KEY, JSON.stringify(queue.slice(0, 300)));
  } catch {}
}

let isSyncingQueue = false;

/**
 * Enfileira uma operação na fila do IndexedDB para sincronização offline resiliente.
 */
export async function enqueuePendingSync(
  table: TableSyncName,
  action: 'insert' | 'update' | 'upsert' | 'delete',
  record: any,
  initialNextRetryTime?: number
): Promise<void> {
  try {
    const rawId = record?.id || `item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const syncId = `sync-${table}-${rawId}`;

    let posAction = `${action}_${table}`;
    if (table === 'vendas' && (action === 'insert' || action === 'upsert')) {
      posAction = 'create_sale';
    } else if (table === 'clientes' && (action === 'insert' || action === 'upsert')) {
      posAction = 'create_customer';
    } else if (table === 'stock') {
      posAction = 'update_stock';
    } else if (table === 'turnos_caixa') {
      posAction = record?.status === 'fechado' ? 'close_shift' : 'update_shift';
    }

    const syncItem: OfflineSyncQueueItem = {
      id: syncId,
      timestamp: new Date().toISOString(),
      action: posAction,
      table,
      entity: table,
      data: record,
      status: 'pending',
      retryCount: 0,
      nextRetryTime: initialNextRetryTime !== undefined ? initialNextRetryTime : Date.now(),
    };

    // Armazenamento principal no IndexedDB
    await offlineDB.enqueueSyncItem(syncItem);

    // Backup em localStorage para compatibilidade
    try {
      const q = getPendingQueue();
      const filtered = q.filter((item) => item.id !== syncId);
      filtered.push({
        id: syncId,
        table,
        action,
        record,
        timestamp: Date.now(),
      });
      savePendingQueue(filtered);
    } catch {}

    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('offline_sync_queue_changed', {
          detail: { action: 'enqueue', table, syncId },
        })
      );
    }
  } catch (err) {
    console.error('[IndexedDB] Erro ao enfileirar operação pendente:', err);
  }
}

/**
 * Reseta os contadores de tempo para retry imediato de toda a fila
 * quando a conectividade é restabelecida.
 */
export async function resetQueueRetryTimers(): Promise<void> {
  try {
    const queue = await offlineDB.getPendingSyncQueue();
    const now = Date.now();
    for (const item of queue) {
      if (item.nextRetryTime && item.nextRetryTime > now) {
        item.nextRetryTime = now;
        await offlineDB.enqueueSyncItem(item);
      }
    }
  } catch (err) {
    console.warn('[resetQueueRetryTimers] Erro ao resetar temporizadores:', err);
  }
}

/**
 * Processa a fila de sincronização do IndexedDB com mecanismo de Retry Exponencial.
 * @param forceAll Se true, ignora o tempo de espera do backoff e tenta sincronizar imediatamente todos os itens pendentes.
 */
export async function flushPendingSyncQueue(forceAll = false): Promise<number> {
  if (isSyncingQueue) {
    return 0;
  }
  isSyncingQueue = true;

  let successCount = 0;

  try {
    // 1. Migração transparente: itens antigos no localStorage migram para IndexedDB
    try {
      const legacyQueue = getPendingQueue();
      if (legacyQueue && legacyQueue.length > 0) {
        for (const leg of legacyQueue) {
          const syncId = leg.id || `sync-${leg.table}-${leg.record?.id || Date.now()}`;
          await offlineDB.enqueueSyncItem({
            id: syncId,
            timestamp: new Date(leg.timestamp || Date.now()).toISOString(),
            action: leg.table === 'vendas' ? 'create_sale' : `${leg.action}_${leg.table}`,
            table: leg.table,
            entity: leg.table,
            data: leg.record,
            status: 'pending',
            retryCount: 0,
            nextRetryTime: Date.now(),
          });
        }
        localStorage.removeItem(PENDING_SYNC_STORAGE_KEY);
      }
    } catch {}

    // 2. Consulta fila principal no IndexedDB
    const queue = await offlineDB.getPendingSyncQueue();
    if (!queue || queue.length === 0) {
      return 0;
    }

    const now = Date.now();

    for (const item of queue) {
      // Se não for forçado, respeitar o temporizador de backoff exponencial
      if (!forceAll && item.nextRetryTime && now < item.nextRetryTime) {
        continue;
      }

      // Marcar item como sincronizando
      item.status = 'syncing';
      await offlineDB.enqueueSyncItem(item);

      let success = false;
      let syncError: any = null;

      try {
        let table: TableSyncName | undefined;
        if (item.table) {
          table = item.table as TableSyncName;
        } else if (item.action === 'create_sale' || item.entity === 'Sale' || item.entity === 'vendas') {
          table = 'vendas';
        } else if (item.action === 'create_customer' || item.entity === 'Customer' || item.entity === 'clientes') {
          table = 'clientes';
        } else if (item.action === 'update_stock' || item.entity === 'Stock' || item.entity === 'stock') {
          table = 'stock';
        } else if (item.action === 'close_shift' || item.action === 'update_shift' || item.entity === 'CashShift' || item.entity === 'turnos_caixa') {
          table = 'turnos_caixa';
        }

        const targetAction: 'insert' | 'update' | 'upsert' | 'delete' = item.action?.startsWith('delete') ? 'delete' : 'upsert';

        if (table) {
          const res = await pushRecordToSupabaseDirect(table, targetAction, item.data, false);
          if (res.success) {
            success = true;
          } else {
            syncError = res.error;
          }
        } else {
          syncError = 'Tabela de destino não identificada';
        }

        if (success) {
          successCount++;
          // Se for venda, marcar arquivamento local como sincronizado
          if ((item.action === 'create_sale' || table === 'vendas') && item.data?.id) {
            await offlineDB.markSaleSynced(item.data.id);
          }
          // Remover com sucesso do IndexedDB
          await offlineDB.removeSyncQueueItem(item.id);
        } else {
          // Falha: Aplicar Retry com Backoff Exponencial inteligente
          const isRls = isRlsError(syncError);
          const nextRetry = (item.retryCount || 0) + 1;
          // Se for bloqueio de segurança RLS (42501), pausar reenvio automático por 10 minutos
          const delayMs = isRls ? 10 * 60 * 1000 : calculateExponentialBackoff(nextRetry);
          const nextRetryTimestamp = Date.now() + delayMs;
          const errorMsg = isRls
            ? `Bloqueado por política RLS na tabela "${table}" (código 42501). Execute o script SQL no Supabase.`
            : (typeof syncError === 'string' ? syncError : syncError?.message || 'Falha ao sincronizar com Supabase');

          await offlineDB.updateSyncItemRetry(item.id, nextRetry, nextRetryTimestamp, errorMsg);

          // Não inundar o log com erros idênticos de RLS se já foram registrados
          if (!isRls || (item.retryCount || 0) === 0) {
            addSyncLog({
              table: (table as string) || 'POS',
              action: 'PUSH',
              origin: 'LOCAL_APP',
              description: isRls
                ? `🛡️ Tabela "${table}" bloqueada por RLS no Supabase (42501). Reenvio automático pausado. Execute o script SQL de permissões.`
                : `⚠️ Tentativa #${nextRetry} falhou (${errorMsg}). Próxima tentativa em ${(delayMs / 1000).toFixed(1)}s (Backoff Exponencial).`,
              status: 'error',
            });
          }
        }
      } catch (err: any) {
        const isRls = isRlsError(err);
        const nextRetry = (item.retryCount || 0) + 1;
        const delayMs = isRls ? 10 * 60 * 1000 : calculateExponentialBackoff(nextRetry);
        const nextRetryTimestamp = Date.now() + delayMs;
        const errorMsg = err?.message || String(err);

        await offlineDB.updateSyncItemRetry(item.id, nextRetry, nextRetryTimestamp, errorMsg);

        if (!isRls || (item.retryCount || 0) === 0) {
          addSyncLog({
            table: (item.table as string) || 'POS',
            action: 'PUSH',
            origin: 'LOCAL_APP',
            description: `⚠️ Erro de rede na tentativa #${nextRetry}. Próxima tentativa em ${(delayMs / 1000).toFixed(1)}s (Backoff Exponencial).`,
            status: 'error',
          });
        }
      }
    }

    if (successCount > 0) {
      addSyncLog({
        table: 'ALL',
        action: 'PUSH',
        origin: 'LOCAL_APP',
        description: `🔄 Fila IndexedDB: ${successCount} operações pendentes sincronizadas com sucesso no Supabase!`,
        status: 'success',
      });
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('offline_sync_queue_changed', {
          detail: { action: 'flush', count: successCount },
        })
      );
    }
  } finally {
    isSyncingQueue = false;
  }

  return successCount;
}

function addSyncLog(log: Omit<SupabaseSyncLog, 'id' | 'timestamp'>) {
  const newLog: SupabaseSyncLog = {
    ...log,
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  };
  syncLogs.unshift(newLog);
  if (syncLogs.length > MAX_LOGS) {
    syncLogs.pop();
  }
  if (currentCallbacks.onLogAdded) {
    currentCallbacks.onLogAdded(newLog);
  }
}

export function getSyncLogs(): SupabaseSyncLog[] {
  return [...syncLogs];
}

export function clearSyncLogs() {
  syncLogs.length = 0;
}

/**
 * Mapeamentos entre o Modelo da Aplicação e as Tabelas do Supabase
 */

export function mapProfileToSupabase(p: any) {
  return {
    id: p.id,
    company_id: p.company_id || p.companyId || 'comp-1',
    full_name: p.full_name || p.fullName || p.name || 'Utilizador',
    email: p.email || '',
    role: p.role || 'caixa',
    avatar_url: p.avatar_url || p.avatarUrl || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToProfile(row: any): UserProfile {
  return {
    id: String(row.id),
    company_id: row.company_id || 'comp-1',
    full_name: row.full_name || row.name || row.nome || 'Utilizador',
    email: row.email || '',
    role: row.role || row.cargo || 'caixa',
    avatar_url: row.avatar_url || '',
    created_at: row.created_at || new Date().toISOString(),
    updated_at: row.updated_at || new Date().toISOString(),
  };
}

export function mapCompanyToSupabase(c: Partial<Company>) {
  return {
    id: c.id || 'comp-1',
    name: c.name || 'Empresa Exemplo',
    trade_name: c.tradeName || null,
    tax_number: c.taxNumber || null,
    address: c.address || null,
    city: c.city || null,
    postal_code: c.postalCode || null,
    country: c.country || 'Moçambique',
    currency: c.currency || 'MZN',
    currency_symbol: c.currencySymbol || 'Mt',
    currency_position: c.currencyPosition || 'suffix',
    currency_decimals: c.currencyDecimals !== undefined ? c.currencyDecimals : 2,
    phone: c.phone || null,
    mobile: c.mobile || null,
    email: c.email || null,
    website: c.website || null,
    logo_url: c.logoUrl || null,
    software_cert_number: c.softwareCertNumber || '0000/AT',
    saft_version: c.saftVersion || '1.04_01',
    share_capital: c.shareCapital || null,
    commercial_registry_number: c.commercialRegistryNumber || null,
    default_iban: c.defaultIban || null,
    default_bank: c.defaultBank || null,
    active_invoice_template_id: c.activeInvoiceTemplateId || 'tmpl-agro-vendus',
    invoice_templates: Array.isArray(c.invoiceTemplates) ? c.invoiceTemplates : [],
    industry: c.industry || null,
    sector: c.sector || null,
    default_tax_rate: c.defaultTaxRate !== undefined ? c.defaultTaxRate : 16,
    default_vat_mode: c.defaultVatMode || 'acrescido',
    vat_rates: Array.isArray(c.vatRates) ? c.vatRates : [],
    logo_position: c.logoPosition || 'left',
    requerimento_doc: c.requerimentoDoc || null,
    memoria_descritiva_doc: c.memoriaDescritivaDoc || null,
    status: c.status || 'active',
    billing_cycle: c.billingCycle || 'monthly',
    subscription_expires_at: c.subscriptionExpiresAt || null,
    subscription_started_at: c.subscriptionStartedAt || null,
    plan: c.plan || 'Plano Profissional',
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToCompany(row: any): Company {
  return {
    id: String(row.id || 'comp-1'),
    name: row.name || 'Empresa',
    tradeName: row.trade_name || row.name || '',
    taxNumber: row.tax_number || '',
    address: row.address || '',
    city: row.city || '',
    postalCode: row.postal_code || '',
    country: row.country || 'Moçambique',
    currency: row.currency || 'MZN',
    currencySymbol: row.currency_symbol || 'Mt',
    currencyPosition: (row.currency_position === 'prefix' ? 'prefix' : 'suffix'),
    currencyDecimals: Number(row.currency_decimals) || 2,
    phone: row.phone || '',
    mobile: row.mobile || '',
    email: row.email || '',
    website: row.website || '',
    logoUrl: row.logo_url || '',
    softwareCertNumber: row.software_cert_number || '0000/AT',
    saftVersion: row.saft_version || '1.04_01',
    shareCapital: row.share_capital || '',
    commercialRegistryNumber: row.commercial_registry_number || '',
    defaultIban: row.default_iban || '',
    defaultBank: row.default_bank || '',
    activeInvoiceTemplateId: row.active_invoice_template_id || 'tmpl-agro-vendus',
    invoiceTemplates: Array.isArray(row.invoice_templates) ? row.invoice_templates : undefined,
    industry: row.industry || undefined,
    sector: row.sector || undefined,
    defaultTaxRate: typeof row.default_tax_rate === 'number' ? row.default_tax_rate : (row.default_tax_rate ? Number(row.default_tax_rate) : 16),
    defaultVatMode: row.default_vat_mode || 'acrescido',
    vatRates: Array.isArray(row.vat_rates) ? row.vat_rates : undefined,
    logoPosition: row.logo_position || 'left',
    requerimentoDoc: row.requerimento_doc || undefined,
    memoriaDescritivaDoc: row.memoria_descritiva_doc || undefined,
    status: row.status || 'active',
    billingCycle: row.billing_cycle || row.billingCycle || 'monthly',
    subscriptionExpiresAt: row.subscription_expires_at || row.subscriptionExpiresAt || undefined,
    subscriptionStartedAt: row.subscription_started_at || row.subscriptionStartedAt || undefined,
    plan: row.plan || 'Plano Profissional',
  };
}

export function mapStoreToSupabase(s: Partial<Store>) {
  return {
    id: s.id || 'store-1',
    company_id: s.companyId || 'comp-1',
    code: s.code || 'LOJA-01',
    name: s.name || 'Loja Principal',
    address: s.address || null,
    city: s.city || null,
    phone: s.phone || null,
    manager_id: s.managerId || null,
    default_warehouse_id: s.defaultWarehouseId || null,
    terminals_count: s.terminalsCount || 1,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToStore(row: any): Store {
  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    code: row.code || 'LOJA-01',
    name: row.name || 'Loja',
    address: row.address || '',
    city: row.city || '',
    phone: row.phone || '',
    managerId: row.manager_id || 'usr-admin',
    defaultWarehouseId: row.default_warehouse_id || 'wh-1',
    terminalsCount: Number(row.terminals_count) || 1,
  };
}

export function mapProductToSupabase(p: Partial<Product>) {
  return {
    id: p.id,
    company_id: p.companyId || 'comp-1',
    sku: p.sku || '',
    barcode: p.barcode || '',
    name: p.name || '',
    category: p.category || '',
    price: p.price || 0,
    cost_price: p.costPrice || 0,
    tax_rate: p.taxRate !== undefined ? p.taxRate : 16,
    unit: p.unit || 'un',
    min_stock: p.minStock || 0,
    max_stock: p.maxStock || 0,
    image_url: p.imageUrl || null,
    has_batch_control: !!p.hasBatchControl,
    supplier_id: p.supplierId || null,
    description: p.description || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToProduct(row: any): Product {
  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    sku: row.sku || '',
    barcode: row.barcode || '',
    name: row.name || 'Artigo sem nome',
    category: row.category || 'Geral',
    price: Number(row.price) || 0,
    costPrice: Number(row.cost_price) || 0,
    taxRate: Number(row.tax_rate) !== undefined ? Number(row.tax_rate) : 16,
    unit: row.unit || 'un',
    minStock: Number(row.min_stock) || 0,
    maxStock: Number(row.max_stock) || 0,
    imageUrl: row.image_url || undefined,
    hasBatchControl: !!row.has_batch_control,
    supplierId: row.supplier_id || undefined,
    description: row.description || undefined,
  };
}

function getFallbackCompanyId(): string {
  try {
    const raw = typeof window !== 'undefined' ? localStorage.getItem('company') : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed?.id) return parsed.id;
    }
  } catch {}
  return 'comp-1';
}

export function mapCustomerToSupabase(c: Partial<Customer>) {
  return {
    id: c.id || `cust-${Date.now()}`,
    company_id: c.companyId || getFallbackCompanyId(),
    name: c.name || '',
    tax_number: c.taxNumber || '',
    email: c.email || '',
    phone: c.phone || '',
    address: c.address || '',
    city: c.city || '',
    postal_code: c.postalCode || '',
    loyalty_points: c.loyaltyPoints || 0,
    loyalty_tier: c.loyaltyTier || 'Bronze',
    total_spent: c.totalSpent || 0,
    credit_limit: c.creditLimit || 0,
    current_credit: c.currentCredit || 0,
    notes: c.notes || null,
    created_at: (c as any).createdAt || (c as any).created_at || new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToCustomer(row: any): Customer {
  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    name: row.name || 'Cliente',
    taxNumber: row.tax_number || '',
    email: row.email || '',
    phone: row.phone || '',
    address: row.address || '',
    city: row.city || '',
    postalCode: row.postal_code || '',
    loyaltyPoints: Number(row.loyalty_points) || 0,
    loyaltyTier: row.loyalty_tier || 'Bronze',
    totalSpent: Number(row.total_spent) || 0,
    creditLimit: Number(row.credit_limit) || 0,
    currentCredit: Number(row.current_credit) || 0,
    createdAt: row.created_at || new Date().toISOString(),
    notes: row.notes || undefined,
  };
}

export function mapSupplierToSupabase(s: Partial<Supplier>) {
  return {
    id: s.id,
    company_id: s.companyId || 'comp-1',
    code: s.code || '',
    name: s.name || '',
    trade_name: s.tradeName || '',
    tax_number: s.taxNumber || '',
    email: s.email || '',
    phone: s.phone || '',
    address: s.address || '',
    payment_terms: s.paymentTerms || '',
    iban: s.iban || '',
    rating: s.rating || 5,
    categories: s.categories || [],
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToSupplier(row: any): Supplier {
  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    code: row.code || '',
    name: row.name || '',
    tradeName: row.trade_name || '',
    taxNumber: row.tax_number || '',
    email: row.email || '',
    phone: row.phone || '',
    address: row.address || '',
    paymentTerms: row.payment_terms || 'Pronto Pagamento',
    iban: row.iban || '',
    rating: Number(row.rating) || 5,
    categories: Array.isArray(row.categories) ? row.categories : [],
  };
}

export function mapCategoryToSupabase(cat: Partial<ProductCategory>) {
  return {
    id: cat.id,
    company_id: cat.companyId || undefined,
    name: cat.name || '',
    icon: cat.icon || null,
    color: cat.color || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToCategory(row: any): ProductCategory {
  return {
    id: String(row.id),
    companyId: row.company_id || undefined,
    name: row.name || 'Geral',
    icon: row.icon || undefined,
    color: row.color || undefined,
  };
}

export function mapSaleToSupabase(s: Partial<Sale>) {
  return {
    id: s.id,
    company_id: s.companyId || 'comp-1',
    store_id: s.storeId || 'store-1',
    terminal_id: s.terminalId || 'term-1',
    invoice_number: s.invoiceNumber || '',
    invoice_type: s.invoiceType || 'FS',
    date: s.date || new Date().toISOString(),
    customer_id: s.customerId || null,
    customer_name: s.customerName || null,
    customer_tax_number: s.customerTaxNumber || s.customerNif || null,
    items: s.items || [],
    subtotal: s.subtotal || 0,
    discount_total: s.discountTotal || 0,
    tax_total: s.taxTotal || 0,
    total: s.total || 0,
    payments: s.payments || [],
    change_amount: s.changeAmount || 0,
    operator_id: s.operatorId || '',
    operator_name: s.operatorName || '',
    shift_id: s.shiftId || '',
    fiscal_hash: s.fiscalHash || '',
    previous_hash: s.previousHash || '',
    atcud: s.atcud || null,
    notes: s.notes || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToSale(row: any, targetCompanyId?: string): Sale {
  // Parse items safely (handles array, JSON string, or Portuguese column names)
  let itemsList: any[] = [];
  const rawItems = row.items || row.itens || row.linhas;
  if (Array.isArray(rawItems)) {
    itemsList = rawItems;
  } else if (typeof rawItems === 'string') {
    try {
      const parsed = JSON.parse(rawItems);
      if (Array.isArray(parsed)) itemsList = parsed;
    } catch {
      itemsList = [];
    }
  }

  // Parse payments safely
  let paymentsList: any[] = [];
  const rawPayments = row.payments || row.pagamentos;
  if (Array.isArray(rawPayments)) {
    paymentsList = rawPayments;
  } else if (typeof rawPayments === 'string') {
    try {
      const parsed = JSON.parse(rawPayments);
      if (Array.isArray(parsed)) paymentsList = parsed;
    } catch {
      paymentsList = [];
    }
  }

  const totalNum = Number(row.total || row.valor_total || row.total_venda || row.montante || 0);

  // If no payments recorded but total > 0, generate fallback payment
  if (paymentsList.length === 0 && totalNum > 0) {
    paymentsList = [
      {
        id: `pay-${row.id || Date.now()}`,
        method: (row.payment_method || row.metodo_pagamento || 'dinheiro') as any,
        amount: totalNum,
      },
    ];
  }

  // Normalize invoice type
  let invType: InvoiceType = 'FS';
  const rawType = String(row.invoice_type || row.invoiceType || row.tipo_fatura || row.tipo_documento || '').trim().toUpperCase();
  if (['FT', 'FS', 'FR', 'NC', 'ND', 'PF', 'ORC', 'GT', 'GR', 'RC', 'VD'].includes(rawType)) {
    invType = rawType as InvoiceType;
  } else if (rawType.includes('FATURA-RECIBO') || rawType.includes('FACTURA-RECIBO')) {
    invType = 'FR';
  } else if (rawType.includes('FATURA') || rawType.includes('FACTURA')) {
    invType = 'FT';
  } else if (rawType.includes('PROFORMA') || rawType.includes('ORÇAMENTO') || rawType.includes('ORCAMENTO')) {
    invType = 'PF';
  } else if (rawType.includes('CREDITO') || rawType.includes('CRÉDITO')) {
    invType = 'NC';
  } else if (rawType.includes('DEBITO') || rawType.includes('DÉBITO')) {
    invType = 'ND';
  } else if (rawType.includes('DINHEIRO')) {
    invType = 'VD';
  } else {
    invType = 'FS';
  }

  const rawCompanyId = row.company_id || row.companyId || row.empresa_id;
  const companyId = rawCompanyId || targetCompanyId || 'comp-1';

  return {
    id: String(row.id),
    companyId,
    storeId: row.store_id || row.storeId || row.loja_id || 'store-1',
    terminalId: row.terminal_id || row.terminalId || 'term-1',
    invoiceNumber: row.invoice_number || row.invoiceNumber || row.numero_fatura || row.numero || 'FS 0/0',
    invoiceType: invType,
    date: row.date || row.data || row.created_at || new Date().toISOString(),
    dueDate: row.due_date || row.dueDate || row.data_vencimento || undefined,
    customerId: row.customer_id || row.customerId || row.cliente_id || undefined,
    customerName: row.customer_name || row.customerName || row.nome_cliente || row.cliente_nome || undefined,
    customerTaxNumber: row.customer_tax_number || row.customerTaxNumber || row.customer_nif || row.customerNif || row.cliente_nif || row.nif || undefined,
    customerNif: row.customer_nif || row.customerNif || row.customer_tax_number || row.customerTaxNumber || row.cliente_nif || row.nif || undefined,
    customerPhone: row.customer_phone || row.customerPhone || row.telefone || row.contacto || undefined,
    customerAddress: row.customer_address || row.customerAddress || row.morada || row.endereco || undefined,
    items: itemsList,
    subtotal: Number(row.subtotal || row.sub_total || row.valor_subtotal || totalNum),
    discountTotal: Number(row.discount_total || row.discountTotal || row.desconto_total || 0),
    taxTotal: Number(row.tax_total || row.taxTotal || row.iva_total || 0),
    total: totalNum,
    vatMode: row.vat_mode || row.vatMode || 'acrescido',
    payments: paymentsList,
    changeAmount: Number(row.change_amount || row.changeAmount || row.troco || 0),
    operatorId: row.operator_id || row.operatorId || row.operador_id || 'usr-1',
    operatorName: row.operator_name || row.operatorName || row.operador_nome || 'Operador',
    shiftId: row.shift_id || row.shiftId || '',
    fiscalHash: row.fiscal_hash || row.fiscalHash || '',
    previousHash: row.previous_hash || row.previousHash || '',
    isSynced: true,
    atcud: row.atcud || row.codigo_atcud || undefined,
    fiscalSeries: row.fiscal_series || row.fiscalSeries || row.serie || undefined,
    invoiceTemplateId: row.invoice_template_id || row.invoiceTemplateId || undefined,
    notes: row.notes || row.observacoes || row.notas || undefined,
    status: row.status || row.estado || 'emitido',
  };
}

export function mapUserToSupabase(u: Partial<User>) {
  const safePin = (!u.pin || u.pin === '1234') ? 'KEYZOM' : u.pin;
  const safePass = (!u.password || u.password === '1234' || u.password === '123456')
    ? (u.role === 'admin' && u.username === 'admin' ? 'admin' : safePin)
    : u.password;

  return {
    id: u.id,
    company_id: u.companyId || 'comp-1',
    store_id: u.storeId || 'store-1',
    nome: u.name || '',
    name: u.name || '',
    email: u.email || '',
    cargo: u.role || 'caixa',
    role: u.role || 'caixa',
    pin: safePin,
    password: safePass,
    senha: safePass,
    telefone: u.phone || null,
    phone: u.phone || null,
    ativo: u.isActive !== undefined ? u.isActive : true,
    is_active: u.isActive !== undefined ? u.isActive : true,
    avatar_url: u.avatarUrl || null,
    permissions: u.permissions || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToUser(row: any): User {
  const rawPin = row.pin ? String(row.pin).trim() : '';
  const safePin = (!rawPin || rawPin === '1234') ? 'KEYZOM' : rawPin;
  const rawPass = row.password || row.senha || '';
  const safePass = (!rawPass || rawPass === '1234' || rawPass === '123456') ? safePin : String(rawPass).trim();

  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    storeId: row.store_id || 'store-1',
    name: row.name || row.nome || 'Utilizador',
    username: row.username || (row.email ? row.email.split('@')[0] : 'user'),
    email: row.email || '',
    password: safePass,
    role: (row.role || row.cargo || 'caixa').toLowerCase(),
    pin: safePin,
    phone: row.phone || row.telefone || '',
    isActive: row.is_active !== undefined ? !!row.is_active : row.ativo !== undefined ? !!row.ativo : true,
    avatarUrl: row.avatar_url || '',
    createdAt: row.created_at || new Date().toISOString().split('T')[0],
    permissions: row.permissions || undefined,
  };
}

export function mapWarehouseToSupabase(w: Partial<Warehouse>) {
  return {
    id: w.id,
    company_id: w.companyId || 'comp-1',
    store_id: w.storeId || null,
    name: w.name || '',
    code: w.code || '',
    location: w.location || '',
    is_default: !!w.isDefault,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToWarehouse(row: any): Warehouse {
  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    storeId: row.store_id || undefined,
    name: row.name || '',
    code: row.code || '',
    location: row.location || '',
    isDefault: !!row.is_default,
  };
}

export function mapAccountPayableToSupabase(a: Partial<AccountPayable>) {
  return {
    id: a.id,
    company_id: a.companyId || 'comp-1',
    supplier_id: a.supplierId || '',
    supplier_name: a.supplierName || '',
    document_number: a.documentNumber || '',
    date: a.date || new Date().toISOString().split('T')[0],
    due_date: a.dueDate || new Date().toISOString().split('T')[0],
    amount: a.amount || 0,
    paid_amount: a.paidAmount || 0,
    status: a.status || 'pendente',
    payment_date: a.paymentDate || null,
    notes: a.notes || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToAccountPayable(row: any): AccountPayable {
  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    supplierId: row.supplier_id || '',
    supplierName: row.supplier_name || '',
    documentNumber: row.document_number || '',
    date: row.date || new Date().toISOString().split('T')[0],
    dueDate: row.due_date || new Date().toISOString().split('T')[0],
    amount: Number(row.amount) || 0,
    paidAmount: Number(row.paid_amount) || 0,
    status: row.status || 'pendente',
    paymentDate: row.payment_date || undefined,
    notes: row.notes || undefined,
  };
}

export function mapAccountReceivableToSupabase(a: Partial<AccountReceivable>) {
  return {
    id: a.id,
    company_id: a.companyId || 'comp-1',
    customer_id: a.customerId || '',
    customer_name: a.customerName || '',
    document_number: a.documentNumber || '',
    date: a.date || new Date().toISOString().split('T')[0],
    due_date: a.dueDate || new Date().toISOString().split('T')[0],
    amount: a.amount || 0,
    received_amount: a.receivedAmount || 0,
    status: a.status || 'pendente',
    receipt_date: a.receiptDate || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToAccountReceivable(row: any): AccountReceivable {
  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    customerId: row.customer_id || '',
    customerName: row.customer_name || '',
    documentNumber: row.document_number || '',
    date: row.date || new Date().toISOString().split('T')[0],
    dueDate: row.due_date || new Date().toISOString().split('T')[0],
    amount: Number(row.amount) || 0,
    receivedAmount: Number(row.received_amount) || 0,
    status: row.status || 'pendente',
    receiptDate: row.receipt_date || undefined,
  };
}

export function mapStockToSupabase(s: Partial<StockItem>) {
  return {
    id: s.id,
    company_id: s.companyId || undefined,
    product_id: s.productId,
    warehouse_id: s.warehouseId,
    quantity: s.quantity || 0,
    reserved: s.reserved || 0,
    avg_cost: s.avgCost || 0,
    batch_number: s.batchNumber || null,
    expiry_date: s.expiryDate || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToStock(row: any): StockItem {
  return {
    id: String(row.id),
    companyId: row.company_id || undefined,
    productId: String(row.product_id),
    warehouseId: String(row.warehouse_id),
    quantity: Number(row.quantity) || 0,
    reserved: Number(row.reserved) || 0,
    avgCost: Number(row.avg_cost) || 0,
    batchNumber: row.batch_number || undefined,
    expiryDate: row.expiry_date || undefined,
  };
}

export function mapShiftToSupabase(s: Partial<CashShift>) {
  return {
    id: s.id,
    company_id: s.companyId || 'comp-1',
    store_id: s.storeId || 'store-1',
    terminal_id: s.terminalId || 'term-1',
    operator_id: s.operatorId || '',
    operator_name: s.operatorName || '',
    opened_at: s.openedAt || new Date().toISOString(),
    closed_at: s.closedAt || null,
    status: s.status || 'aberto',
    initial_cash: s.initialCash || 0,
    final_cash_reported: typeof s.finalCashReported === 'number' ? s.finalCashReported : null,
    final_cash_system: typeof s.finalCashSystem === 'number' ? s.finalCashSystem : null,
    cash_difference: s.cashDifference || 0,
    total_sales: s.totalSales || 0,
    total_cash: s.totalCash || 0,
    total_cards: s.totalCards || 0,
    total_mbway: s.totalMbway || 0,
    total_transfers: s.totalTransfers || 0,
    total_vouchers: s.totalVouchers || 0,
    sangria_total: s.sangriaTotal || 0,
    suprimento_total: s.suprimentoTotal || 0,
    movements: s.movements || [],
    z_report_number: s.zReportNumber || null,
    notes: s.notes || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToShift(row: any): CashShift {
  return {
    id: String(row.id),
    companyId: row.company_id || 'comp-1',
    storeId: row.store_id || 'store-1',
    terminalId: row.terminal_id || 'term-1',
    operatorId: row.operator_id || '',
    operatorName: row.operator_name || '',
    openedAt: row.opened_at || new Date().toISOString(),
    closedAt: row.closed_at || undefined,
    status: row.status || 'aberto',
    initialCash: Number(row.initial_cash) || 0,
    finalCashReported: row.final_cash_reported !== null ? Number(row.final_cash_reported) : undefined,
    finalCashSystem: row.final_cash_system !== null ? Number(row.final_cash_system) : undefined,
    cashDifference: Number(row.cash_difference) || 0,
    totalSales: Number(row.total_sales) || 0,
    totalCash: Number(row.total_cash) || 0,
    totalCards: Number(row.total_cards) || 0,
    totalMbway: Number(row.total_mbway) || 0,
    totalTransfers: Number(row.total_transfers) || 0,
    totalVouchers: Number(row.total_vouchers) || 0,
    sangriaTotal: Number(row.sangria_total) || 0,
    suprimentoTotal: Number(row.suprimento_total) || 0,
    movements: Array.isArray(row.movements) ? row.movements : [],
    zReportNumber: row.z_report_number || undefined,
    notes: row.notes || undefined,
  };
}

export function mapEmployeeToSupabase(e: Partial<Employee>) {
  return {
    id: e.id,
    company_id: e.companyId || 'comp-1',
    code: e.code || '',
    name: e.name || '',
    role: e.role || '',
    department: e.department || '',
    store_id: e.storeId || '',
    tax_number: e.taxNumber || '',
    social_security_number: e.socialSecurityNumber || '',
    email: e.email || '',
    phone: e.phone || '',
    base_salary: Number(e.baseSalary || 0),
    meal_allowance_daily: Number(e.mealAllowanceDaily || 0),
    contract_type: e.contractType || 'sem_termo',
    admission_date: e.admissionDate || '',
    status: e.status || 'ativo',
    avatar_url: e.avatarUrl || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToEmployee(row: any): Employee {
  return {
    id: String(row.id || ''),
    companyId: String(row.company_id || 'comp-1'),
    code: String(row.code || ''),
    name: String(row.name || ''),
    role: String(row.role || ''),
    department: String(row.department || ''),
    storeId: String(row.store_id || ''),
    taxNumber: String(row.tax_number || ''),
    socialSecurityNumber: String(row.social_security_number || ''),
    email: String(row.email || ''),
    phone: String(row.phone || ''),
    baseSalary: Number(row.base_salary || 0),
    mealAllowanceDaily: Number(row.meal_allowance_daily || 0),
    contractType: row.contract_type || 'sem_termo',
    admissionDate: String(row.admission_date || ''),
    status: row.status || 'ativo',
    avatarUrl: row.avatar_url || undefined,
  };
}

export function mapTimeEntryToSupabase(t: Partial<TimeClockEntry> & { companyId?: string }) {
  return {
    id: t.id || `time-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    company_id: (t as any).companyId || (t as any).company_id || 'comp-1',
    employee_id: t.employeeId || (t as any).employee_id || 'emp-colaborador-1',
    employee_name: t.employeeName || (t as any).employee_name || 'Colaborador',
    store_id: t.storeId || (t as any).store_id || 'store-1',
    date: t.date || new Date().toISOString().split('T')[0],
    clock_in: t.clockIn || (t as any).clock_in || '08:00',
    lunch_out: t.lunchOut || (t as any).lunch_out || null,
    lunch_in: t.lunchIn || (t as any).lunch_in || null,
    clock_out: t.clockOut || (t as any).clock_out || '17:00',
    total_hours: Number(t.totalHours || 0),
    overtime_hours: Number(t.overtimeHours || 0),
    status: t.status || 'completo',
    approved_by: (t as any).approvedBy || (t as any).approved_by || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToTimeEntry(row: any): TimeClockEntry {
  return {
    id: String(row.id || ''),
    employeeId: String(row.employee_id || ''),
    employeeName: String(row.employee_name || ''),
    storeId: String(row.store_id || ''),
    date: String(row.date || ''),
    clockIn: String(row.clock_in || ''),
    lunchOut: row.lunch_out || undefined,
    lunchIn: row.lunch_in || undefined,
    clockOut: row.clock_out || undefined,
    totalHours: Number(row.total_hours || 0),
    overtimeHours: Number(row.overtime_hours || 0),
    status: row.status || 'completo',
    ...(row.approved_by ? { approvedBy: row.approved_by } : {}),
    ...(row.company_id ? { companyId: row.company_id } : {}),
  } as any;
}

export function mapPayrollToSupabase(p: Partial<PayrollSlip>) {
  const monthYear = p.monthYear || (p as any).month || (p as any).month_year || `${new Date().getMonth() + 1}/${new Date().getFullYear()}`;
  return {
    id: p.id || `payroll-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    company_id: p.companyId || (p as any).company_id || 'comp-1',
    employee_id: p.employeeId || (p as any).employee_id || 'emp-colaborador-1',
    employee_name: p.employeeName || (p as any).employee_name || 'Colaborador',
    employee_role: p.employeeRole || (p as any).employee_role || 'Operador',
    tax_number: p.taxNumber || (p as any).tax_number || '',
    month_year: monthYear,
    month: monthYear,
    base_salary: Number(p.baseSalary || 0),
    meal_allowance: Number(p.mealAllowance || 0),
    overtime_pay: Number(p.overtimePay || 0),
    bonus: Number(p.bonus || 0),
    gross_total: Number(p.grossTotal || 0),
    social_security_deduction: Number(p.socialSecurityDeduction || 0),
    social_security_retention: Number((p as any).socialSecurityRetention || p.socialSecurityDeduction || 0),
    irs_retention: Number(p.irsRetention || 0),
    net_salary: Number(p.netSalary || 0),
    company_social_security: Number(p.companySocialSecurity || 0),
    total_employer_cost: Number(p.totalEmployerCost || 0),
    status: p.status || 'processado',
    payment_date: p.paymentDate || null,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToPayroll(row: any): PayrollSlip {
  return {
    id: String(row.id || ''),
    companyId: String(row.company_id || 'comp-1'),
    employeeId: String(row.employee_id || ''),
    employeeName: String(row.employee_name || ''),
    employeeRole: String(row.employee_role || ''),
    taxNumber: String(row.tax_number || ''),
    monthYear: String(row.month_year || row.month || ''),
    month: String(row.month || row.month_year || ''),
    baseSalary: Number(row.base_salary || 0),
    mealAllowance: Number(row.meal_allowance || 0),
    overtimePay: Number(row.overtime_pay || 0),
    bonus: Number(row.bonus || 0),
    grossTotal: Number(row.gross_total || 0),
    socialSecurityDeduction: Number(row.social_security_deduction || 0),
    socialSecurityRetention: Number(row.social_security_retention || row.social_security_deduction || 0),
    irsRetention: Number(row.irs_retention || 0),
    netSalary: Number(row.net_salary || 0),
    companySocialSecurity: Number(row.company_social_security || 0),
    totalEmployerCost: Number(row.total_employer_cost || 0),
    status: row.status || 'processado',
    paymentDate: row.payment_date || undefined,
  } as any;
}

export function mapEmployeeShiftToSupabase(s: Partial<EmployeeShift>) {
  return {
    id: s.id || `shift-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    company_id: (s as any).companyId || (s as any).company_id || 'comp-1',
    employee_id: s.employeeId || (s as any).employee_id || 'emp-colaborador-1',
    store_id: s.storeId || (s as any).store_id || 'store-1',
    date: s.date || new Date().toISOString().split('T')[0],
    start_time: s.startTime || (s as any).start_time || '08:00',
    end_time: s.endTime || (s as any).end_time || '17:00',
    break_duration_minutes: Number(s.breakDurationMinutes || 60),
    role_assigned: s.roleAssigned || (s as any).role_assigned || 'Operador',
    status: s.status || 'planeado',
    notes: (s as any).notes || '',
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToEmployeeShift(row: any): EmployeeShift {
  return {
    id: String(row.id || ''),
    employeeId: String(row.employee_id || ''),
    companyId: String(row.company_id || 'comp-1'),
    storeId: String(row.store_id || ''),
    date: String(row.date || ''),
    startTime: String(row.start_time || ''),
    endTime: String(row.end_time || ''),
    breakDurationMinutes: Number(row.break_duration_minutes || 60),
    roleAssigned: String(row.role_assigned || ''),
    status: row.status || 'planeado',
    notes: row.notes || undefined,
  } as any;
}

export function mapSalesGoalToSupabase(g: Partial<SalesGoalRecord>) {
  const companyId = g.companyId || 'comp-1';
  const ano = Number(g.anoReferencia || new Date().getFullYear());
  const id = g.id || `goal_${companyId}_${ano}`;
  return {
    id,
    company_id: companyId,
    ano_referencia: ano,
    meta_anual_total: Number(g.metaAnualTotal || 0),
    estrategia: g.estrategia || 'MANUAL',
    metas_mensais: g.metasMensais || [],
    valores_manuais: g.valoresManuais || [],
    historico_valores: g.historicoValores || [],
    vendas_realizadas: g.vendasRealizadas || [],
    saved_at: g.savedAt || new Date().toISOString(),
    source: g.source || 'Manual / Ajuste Local',
    is_manually_edited: g.isManuallyEdited !== undefined ? g.isManuallyEdited : true,
    updated_at: new Date().toISOString(),
  };
}

export function mapSupabaseToSalesGoal(row: any): SalesGoalRecord {
  return {
    id: String(row.id || ''),
    companyId: String(row.company_id || 'comp-1'),
    anoReferencia: Number(row.ano_referencia || new Date().getFullYear()),
    metaAnualTotal: Number(row.meta_anual_total || 0),
    estrategia: String(row.estrategia || 'MANUAL'),
    metasMensais: Array.isArray(row.metas_mensais) ? row.metas_mensais : [],
    valoresManuais: Array.isArray(row.valores_manuais) ? row.valores_manuais : [],
    historicoValores: Array.isArray(row.historico_valores) ? row.historico_valores : [],
    vendasRealizadas: Array.isArray(row.vendas_realizadas) ? row.vendas_realizadas : [],
    savedAt: row.saved_at || undefined,
    source: row.source || undefined,
    isManuallyEdited: Boolean(row.is_manually_edited),
    updatedAt: row.updated_at || undefined,
  };
}

/**
 * ============================================================================
 * SINCRONIZAÇÃO BIDIRECIONAL EM TEMPO REAL (REALTIME SUBSCRIBER)
 * ============================================================================
 */

export function startSupabaseRealtimeSync(callbacks: RealtimeSyncCallbacks) {
  currentCallbacks = callbacks;

  if (reconnectTimeout) {
    clearTimeout(reconnectTimeout);
    reconnectTimeout = null;
  }

  if (activeChannel) {
    try {
      supabase.removeChannel(activeChannel);
    } catch {}
    activeChannel = null;
  }

  if (callbacks.onStatusChange) {
    callbacks.onStatusChange('connecting');
  }

  addSyncLog({
    table: 'ALL',
    action: 'PULL',
    origin: 'LOCAL_APP',
    description: 'A iniciar conexão e escuta Realtime contínua com o Supabase...',
    status: 'info',
  });

  const channel = supabase.channel('erp-pos-realtime-master');

  const registeredTables: TableSyncName[] = [
    'profiles',
    'empresas',
    'lojas',
    'produtos',
    'clientes',
    'fornecedores',
    'categorias',
    'vendas',
    'usuarios',
    'armazens',
    'stock',
    'contas_pagar',
    'contas_receber',
    'turnos_caixa',
    'colaboradores',
    'registos_ponto',
    'recibos_salario',
    'escalas_trabalho',
    'metas_vendas',
  ];

  registeredTables.forEach((tableName) => {
    channel.on(
      'postgres_changes',
      { event: '*', schema: 'public', table: tableName },
      (payload: any) => {
        handleRealtimeEvent(tableName, payload);
      }
    );
  });

  channel.subscribe((status: string, err: any) => {
    if (status === 'SUBSCRIBED') {
      isReconnecting = false;
      if (currentCallbacks.onStatusChange) {
        currentCallbacks.onStatusChange('connected');
      }
      addSyncLog({
        table: 'ALL',
        action: 'PULL',
        origin: 'SUPABASE_REALTIME',
        description: '🟢 Canal Realtime conectado e sincronizado em direto (bidirecional ativo)!',
        status: 'success',
      });
      // Flush any queued offline actions immediately upon connecting
      flushPendingSyncQueue().catch(() => {});
    } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
      if (currentCallbacks.onStatusChange) {
        currentCallbacks.onStatusChange('error', err?.message || 'Conexão Realtime interrompida');
      }
      addSyncLog({
        table: 'ALL',
        action: 'ERROR',
        origin: 'SUPABASE_REALTIME',
        description: `Canal Realtime: ${status} (${err?.message || 'A tentar reconectar em 5 segundos...'})`,
        status: 'error',
      });
      // Auto-reconnect with retry timer
      if (!isReconnecting) {
        isReconnecting = true;
        reconnectTimeout = setTimeout(() => {
          isReconnecting = false;
          if (currentCallbacks) {
            startSupabaseRealtimeSync(currentCallbacks);
          }
        }, 5000);
      }
    }
  });

  activeChannel = channel;

  // Listen to browser online event to restore connection & flush queue
  if (typeof window !== 'undefined') {
    const handleOnline = async () => {
      addSyncLog({
        table: 'ALL',
        action: 'PULL',
        origin: 'LOCAL_APP',
        description: '🌐 Ligação à Internet restabelecida. A restabelecer canal Supabase e reprocessar fila do IndexedDB...',
        status: 'info',
      });
      startSupabaseRealtimeSync(callbacks);
      await resetQueueRetryTimers();
      flushPendingSyncQueue(true).catch(() => {});
    };
    window.removeEventListener('online', handleOnline);
    window.addEventListener('online', handleOnline);
  }

  return activeChannel;
}

export function stopSupabaseRealtimeSync() {
  if (reconnectTimeout) {
    clearTimeout(reconnectTimeout);
    reconnectTimeout = null;
  }
  if (activeChannel) {
    try {
      supabase.removeChannel(activeChannel);
    } catch {}
    activeChannel = null;
  }
  if (currentCallbacks.onStatusChange) {
    currentCallbacks.onStatusChange('disconnected');
  }
}

// Inicialização de sincronizador automático periódico em segundo plano para retries exponenciais
if (typeof window !== 'undefined') {
  setInterval(() => {
    if (typeof navigator !== 'undefined' && navigator.onLine) {
      flushPendingSyncQueue(false).catch(() => {});
    }
  }, 8000);
}

function handleRealtimeEvent(tableName: TableSyncName, payload: any) {
  const { eventType, new: newRecord, old: oldRecord } = payload;
  const rawId = (oldRecord && oldRecord.id) || (newRecord && newRecord.id);

  addSyncLog({
    table: tableName,
    action: eventType as any,
    origin: 'SUPABASE_REALTIME',
    description: `Evento Realtime [${eventType}] na tabela "${tableName}" (ID: ${rawId || 'desconhecido'})`,
    status: 'info',
    data: eventType === 'DELETE' ? oldRecord : newRecord,
  });

  switch (tableName) {
    case 'profiles':
      if (currentCallbacks.onProfileChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToProfile(newRecord);
        currentCallbacks.onProfileChange(eventType, item, oldRecord);
      }
      break;

    case 'empresas':
      if (currentCallbacks.onCompanyChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToCompany(newRecord);
        currentCallbacks.onCompanyChange(eventType, item, oldRecord);
      }
      break;

    case 'lojas':
      if (currentCallbacks.onStoreChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToStore(newRecord);
        currentCallbacks.onStoreChange(eventType, item, oldRecord);
      }
      break;

    case 'produtos':
      if (currentCallbacks.onProductChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToProduct(newRecord);
        currentCallbacks.onProductChange(eventType, item, oldRecord);
      }
      break;

    case 'clientes':
      if (currentCallbacks.onCustomerChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToCustomer(newRecord);
        currentCallbacks.onCustomerChange(eventType, item, oldRecord);
      }
      break;

    case 'fornecedores':
      if (currentCallbacks.onSupplierChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToSupplier(newRecord);
        currentCallbacks.onSupplierChange(eventType, item, oldRecord);
      }
      break;

    case 'categorias':
      if (currentCallbacks.onCategoryChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToCategory(newRecord);
        currentCallbacks.onCategoryChange(eventType, item, oldRecord);
      }
      break;

    case 'vendas':
      if (currentCallbacks.onSaleChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToSale(newRecord);
        currentCallbacks.onSaleChange(eventType, item, oldRecord);
      }
      break;

    case 'usuarios':
      if (currentCallbacks.onUserChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToUser(newRecord);
        currentCallbacks.onUserChange(eventType, item, oldRecord);
      }
      break;

    case 'armazens':
      if (currentCallbacks.onWarehouseChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToWarehouse(newRecord);
        currentCallbacks.onWarehouseChange(eventType, item, oldRecord);
      }
      break;

    case 'stock':
      if (currentCallbacks.onStockChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToStock(newRecord);
        currentCallbacks.onStockChange(eventType, item, oldRecord);
      }
      break;

    case 'contas_pagar':
      if (currentCallbacks.onAccountPayableChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToAccountPayable(newRecord);
        currentCallbacks.onAccountPayableChange(eventType, item, oldRecord);
      }
      break;

    case 'contas_receber':
      if (currentCallbacks.onAccountReceivableChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToAccountReceivable(newRecord);
        currentCallbacks.onAccountReceivableChange(eventType, item, oldRecord);
      }
      break;

    case 'turnos_caixa':
      if (currentCallbacks.onShiftChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToShift(newRecord);
        currentCallbacks.onShiftChange(eventType, item, oldRecord);
      }
      break;

    case 'colaboradores':
      if (currentCallbacks.onEmployeeChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToEmployee(newRecord);
        currentCallbacks.onEmployeeChange(eventType, item, oldRecord);
      }
      break;

    case 'registos_ponto':
      if (currentCallbacks.onTimeEntryChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToTimeEntry(newRecord);
        currentCallbacks.onTimeEntryChange(eventType, item, oldRecord);
      }
      break;

    case 'recibos_salario':
      if (currentCallbacks.onPayrollChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToPayroll(newRecord);
        currentCallbacks.onPayrollChange(eventType, item, oldRecord);
      }
      break;

    case 'escalas_trabalho':
      if (currentCallbacks.onEmployeeShiftChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToEmployeeShift(newRecord);
        currentCallbacks.onEmployeeShiftChange(eventType, item, oldRecord);
      }
      break;

    case 'metas_vendas':
      if (currentCallbacks.onSalesGoalChange) {
        const item = eventType === 'DELETE' ? { id: String(rawId) } : mapSupabaseToSalesGoal(newRecord);
        currentCallbacks.onSalesGoalChange(eventType, item, oldRecord);
      }
      break;
  }
}

/**
 * ============================================================================
 * ENVIO DE AÇÕES LOCAIS PARA O SUPABASE (PUSH CRUD)
 * ============================================================================
 */

export function mapLocalRecordToSupabasePayload(table: TableSyncName, record: any): any {
  switch (table) {
    case 'profiles':
      return mapProfileToSupabase(record);
    case 'empresas':
      return mapCompanyToSupabase(record);
    case 'lojas':
      return mapStoreToSupabase(record);
    case 'produtos':
      return mapProductToSupabase(record);
    case 'clientes':
      return mapCustomerToSupabase(record);
    case 'fornecedores':
      return mapSupplierToSupabase(record);
    case 'categorias':
      return mapCategoryToSupabase(record);
    case 'vendas':
      return mapSaleToSupabase(record);
    case 'usuarios':
      return mapUserToSupabase(record);
    case 'armazens':
      return mapWarehouseToSupabase(record);
    case 'stock':
      return mapStockToSupabase(record);
    case 'contas_pagar':
      return mapAccountPayableToSupabase(record);
    case 'contas_receber':
      return mapAccountReceivableToSupabase(record);
    case 'turnos_caixa':
      return mapShiftToSupabase(record);
    case 'colaboradores':
      return mapEmployeeToSupabase(record);
    case 'registos_ponto':
      return mapTimeEntryToSupabase(record);
    case 'recibos_salario':
      return mapPayrollToSupabase(record);
    case 'escalas_trabalho':
      return mapEmployeeShiftToSupabase(record);
    case 'metas_vendas':
      return mapSalesGoalToSupabase(record);
    default:
      return record;
  }
}

export async function pushRecordToSupabaseDirect(
  table: TableSyncName,
  action: 'insert' | 'update' | 'upsert' | 'delete',
  record: any,
  shouldQueueOnFailure = true
): Promise<{ success: boolean; error?: any }> {
  try {
    let payload: any = record;

    if (action === 'delete') {
      const id = record?.id || record;
      if (!id) return { success: false, error: 'ID ausente para exclusão' };

      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) {
        if (isTableMissingError(error)) {
          return { success: false, error: `Tabela "${table}" ainda não criada no Supabase (PGRST205/42P01)` };
        }
        if (shouldQueueOnFailure) {
          enqueuePendingSync(table, action, record);
        }
        addSyncLog({
          table,
          action: 'DELETE',
          origin: 'LOCAL_APP',
          description: `Erro ao eliminar registo "${id}" no Supabase: ${error.message}`,
          status: 'error',
        });
        return { success: false, error };
      }

      addSyncLog({
        table,
        action: 'DELETE',
        origin: 'LOCAL_APP',
        description: `Registo "${id}" eliminado com sucesso no Supabase`,
        status: 'success',
      });
      return { success: true };
    }

    payload = mapLocalRecordToSupabasePayload(table, record);

    if (action === 'insert' || action === 'upsert') {
      const { error } = await supabase.from(table).upsert(payload);
      if (error) throw error;
    } else if (action === 'update') {
      const { error } = await supabase.from(table).update(payload).eq('id', payload.id);
      if (error) {
        // Fallback to upsert if update fails (e.g. record not yet found in Supabase)
        const { error: upsertError } = await supabase.from(table).upsert(payload);
        if (upsertError) throw upsertError;
      }
    }

    addSyncLog({
      table,
      action: action.toUpperCase() as any,
      origin: 'LOCAL_APP',
      description: `Registo "${payload.name || payload.code || payload.id}" sincronizado no Supabase`,
      status: 'success',
    });

    return { success: true };
  } catch (error: any) {
    if (isTableMissingError(error)) {
      return { success: false, error: `Tabela "${table}" ainda não configurada no Supabase (PGRST205/42P01)` };
    }
    const isRls = isRlsError(error);
    if (shouldQueueOnFailure) {
      // Se for erro de RLS (42501), agendar retry para daqui a 10 min para não poluir
      enqueuePendingSync(table, action, record, isRls ? Date.now() + 10 * 60 * 1000 : undefined);
    }
    throttledWarn(
      `sync-err-${table}`,
      isRls
        ? `[Supabase RLS 42501] Permissão negada pela política de segurança (Row-Level Security) na tabela "${table}". Execute o script SQL no Supabase para conceder acesso à chave pública anon.`
        : `Erro ao sincronizar com Supabase na tabela ${table}:`,
      isRls ? error?.message || error : error
    );
    addSyncLog({
      table,
      action: action.toUpperCase() as any,
      origin: 'LOCAL_APP',
      description: isRls
        ? `🛡️ Bloqueio RLS na tabela "${table}" (42501). Aplique o script SQL no Supabase para conceder permissões à chave anon.`
        : `Erro ao enviar para o Supabase (enfileirado para reenvio automático): ${error?.message || error}`,
      status: 'error',
    });
    return { success: false, error };
  }
}

export async function pushRecordToSupabase(
  table: TableSyncName,
  action: 'insert' | 'update' | 'upsert' | 'delete',
  record: any
): Promise<{ success: boolean; error?: any }> {
  return pushRecordToSupabaseDirect(table, action, record, true);
}

export async function pushBatchRecordsToSupabase(
  table: TableSyncName,
  action: 'insert' | 'update' | 'upsert',
  records: any[]
): Promise<{ success: boolean; error?: any }> {
  if (!records || records.length === 0) return { success: true };
  try {
    const payloads = records.map((r) => mapLocalRecordToSupabasePayload(table, r));
    const CHUNK_SIZE = 50;

    for (let i = 0; i < payloads.length; i += CHUNK_SIZE) {
      const chunk = payloads.slice(i, i + CHUNK_SIZE);
      // Always prefer upsert to avoid duplicate key or concurrency conflicts
      const { error } = await supabase.from(table).upsert(chunk);
      if (error) throw error;
    }

    addSyncLog({
      table,
      action: action.toUpperCase() as any,
      origin: 'LOCAL_APP',
      description: `${records.length} registos em lote sincronizados na tabela "${table}" do Supabase`,
      status: 'success',
    });
    return { success: true };
  } catch (error: any) {
    if (isTableMissingError(error)) {
      return { success: false, error: `Tabela "${table}" ainda não configurada no Supabase (PGRST205/42P01)` };
    }
    const isRls = isRlsError(error);
    // Queue individual items for retry
    records.forEach((r) => enqueuePendingSync(table, action, r, isRls ? Date.now() + 10 * 60 * 1000 : undefined));
    throttledWarn(
      `batch-err-${table}`,
      isRls
        ? `[Supabase RLS 42501] Envio em lote na tabela "${table}" bloqueado por segurança RLS.`
        : `Erro ao sincronizar lote na tabela ${table}:`,
      isRls ? error?.message || error : error
    );
    addSyncLog({
      table,
      action: action.toUpperCase() as any,
      origin: 'LOCAL_APP',
      description: isRls
        ? `🛡️ Envio de lote bloqueado por política RLS na tabela "${table}" (42501).`
        : `Erro no envio em lote (${records.length} registos guardados na fila de reenvio): ${error?.message || error}`,
      status: 'error',
    });
    return { success: false, error };
  }
}

/**
 * ============================================================================
 * PUXAR UMA TABELA ESPECÍFICA DO SUPABASE (SINGLE TABLE PULL)
 * ============================================================================
 */
export async function pullTableFromSupabase(
  table: TableSyncName,
  options?: { companyId?: string; profileId?: string }
): Promise<{
  success: boolean;
  data: any[];
  count: number;
  error?: string;
}> {
  let mapper: (row: any) => any = (r) => r;
  switch (table) {
    case 'profiles': mapper = mapSupabaseToProfile; break;
    case 'empresas': mapper = mapSupabaseToCompany; break;
    case 'lojas': mapper = mapSupabaseToStore; break;
    case 'produtos': mapper = mapSupabaseToProduct; break;
    case 'clientes': mapper = mapSupabaseToCustomer; break;
    case 'fornecedores': mapper = mapSupabaseToSupplier; break;
    case 'categorias': mapper = mapSupabaseToCategory; break;
    case 'vendas': mapper = mapSupabaseToSale; break;
    case 'usuarios': mapper = mapSupabaseToUser; break;
    case 'armazens': mapper = mapSupabaseToWarehouse; break;
    case 'stock': mapper = mapSupabaseToStock; break;
    case 'contas_pagar': mapper = mapSupabaseToAccountPayable; break;
    case 'contas_receber': mapper = mapSupabaseToAccountReceivable; break;
    case 'turnos_caixa': mapper = mapSupabaseToShift; break;
    case 'colaboradores': mapper = mapSupabaseToEmployee; break;
    case 'registos_ponto': mapper = mapSupabaseToTimeEntry; break;
    case 'recibos_salario': mapper = mapSupabaseToPayroll; break;
    case 'escalas_trabalho': mapper = mapSupabaseToEmployeeShift; break;
    case 'metas_vendas': mapper = mapSupabaseToSalesGoal; break;
  }

  try {
    let query: any = supabase.from(table).select('*');
    
    // Apply Company scoping (never filter empresas by companyId so tenant discovery works)
    if (options?.companyId && options.companyId !== 'ALL' && table !== 'empresas') {
      if (table === 'vendas') {
        // Resilient company scoping: allow matching target company, default 'comp-1', or null
        query = query.or(`company_id.eq.${options.companyId},company_id.eq.comp-1,company_id.is.null`);
      } else {
        query = query.eq('company_id', options.companyId);
      }
    }

    // Apply specific ordering per table
    if (table === 'produtos' || table === 'categorias' || table === 'lojas' || table === 'armazens') {
      query = query.order('name', { ascending: true });
    } else if (table === 'usuarios') {
      query = query.order('nome', { ascending: true });
    } else if (table === 'vendas') {
      query = query.order('date', { ascending: false });
    } else if (table === 'colaboradores') {
      query = query.order('name', { ascending: true });
    } else if (table === 'registos_ponto') {
      query = query.order('date', { ascending: false });
    } else if (table === 'recibos_salario') {
      query = query.order('month_year', { ascending: false });
    } else if (table === 'escalas_trabalho') {
      query = query.order('date', { ascending: false });
    } else if (table === 'metas_vendas') {
      query = query.order('ano_referencia', { ascending: false });
    } else if (table === 'turnos_caixa') {
      query = query.order('opened_at', { ascending: false });
    }

    // Apply Profile scoping
    if (options?.profileId && options.profileId !== 'ALL' && table === 'profiles') {
      query = query.eq('id', options.profileId);
    }

    const { data, error } = await query;
    if (error) {
      const errorMsg = isTableMissingError(error)
        ? `Tabela "${table}" ainda não existe no Supabase. Execute o script SQL no Supabase.`
        : `Erro ao ler "${table}": ${error.message}`;
      
      addSyncLog({
        table,
        action: 'ERROR',
        origin: 'LOCAL_APP',
        description: errorMsg,
        status: 'error',
      });
      return { success: false, data: [], count: 0, error: errorMsg };
    }

    let mapped = Array.isArray(data)
      ? data.map((row) => (table === 'vendas' ? mapSupabaseToSale(row, options?.companyId !== 'ALL' ? options?.companyId : undefined) : mapper(row)))
      : [];

    if (table === 'vendas' && options?.companyId && options.companyId !== 'ALL') {
      mapped = mapped.map((s: Sale) => ({
        ...s,
        companyId: s.companyId && s.companyId !== 'comp-1' ? s.companyId : options.companyId!,
      }));
    }

    // Ensure system-wide alphabetical sorting on products
    if (table === 'produtos') {
      mapped = mapped.sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt', { sensitivity: 'base', numeric: true }));
    }
    const scopeDesc = options?.companyId && options.companyId !== 'ALL'
      ? ` (Empresa: ${options.companyId})`
      : '';
    addSyncLog({
      table,
      action: 'PULL',
      origin: 'LOCAL_APP',
      description: `Puxados ${mapped.length} registos da tabela "${table}" do Supabase${scopeDesc}.`,
      status: 'success',
    });
    return { success: true, data: mapped, count: mapped.length };
  } catch (err: any) {
    const errorMsg = err?.message || String(err);
    return { success: false, data: [], count: 0, error: errorMsg };
  }
}

/**
 * ============================================================================
 * ENVIAR UMA TABELA ESPECÍFICA PARA O SUPABASE (SINGLE TABLE PUSH)
 * ============================================================================
 */
export async function pushTableToSupabase(
  table: TableSyncName,
  items: any[],
  options?: { companyId?: string }
): Promise<{
  success: boolean;
  count: number;
  error?: string;
}> {
  if (!items || items.length === 0) {
    return { success: true, count: 0 };
  }

  let mapper: (item: any) => any = (i) => i;
  switch (table) {
    case 'profiles': mapper = mapProfileToSupabase; break;
    case 'empresas': mapper = mapCompanyToSupabase; break;
    case 'lojas': mapper = mapStoreToSupabase; break;
    case 'produtos': mapper = mapProductToSupabase; break;
    case 'clientes': mapper = mapCustomerToSupabase; break;
    case 'fornecedores': mapper = mapSupplierToSupabase; break;
    case 'categorias': mapper = mapCategoryToSupabase; break;
    case 'vendas': mapper = mapSaleToSupabase; break;
    case 'usuarios': mapper = mapUserToSupabase; break;
    case 'armazens': mapper = mapWarehouseToSupabase; break;
    case 'stock': mapper = mapStockToSupabase; break;
    case 'contas_pagar': mapper = mapAccountPayableToSupabase; break;
    case 'contas_receber': mapper = mapAccountReceivableToSupabase; break;
    case 'turnos_caixa': mapper = mapShiftToSupabase; break;
    case 'colaboradores': mapper = mapEmployeeToSupabase; break;
    case 'registos_ponto': mapper = mapTimeEntryToSupabase; break;
    case 'recibos_salario': mapper = mapPayrollToSupabase; break;
    case 'escalas_trabalho': mapper = mapEmployeeShiftToSupabase; break;
    case 'metas_vendas': mapper = mapSalesGoalToSupabase; break;
  }

  try {
    let payload = items.map(mapper);

    // If scoped by company, ensure company_id is stamped
    if (options?.companyId && options.companyId !== 'ALL') {
      payload = payload.map((row) => {
        if (table === 'empresas') {
          return { ...row, id: row.id || options.companyId };
        }
        return { ...row, company_id: options.companyId };
      });
    }

    // Batch in chunks of 50 to avoid request size limits
    const CHUNK_SIZE = 50;
    let uploadedCount = 0;

    for (let i = 0; i < payload.length; i += CHUNK_SIZE) {
      const chunk = payload.slice(i, i + CHUNK_SIZE);
      const { error } = await supabase.from(table).upsert(chunk);
      if (error) {
        let cleanMsg = error.message;
        if (isTableMissingError(error)) {
          cleanMsg = `Tabela "${table}" não existe no Supabase. Crie as tabelas com o script SQL.`;
        } else if (error.code === '42501' || error.message?.includes('row-level security') || error.message?.includes('policy')) {
          cleanMsg = `Bloqueado por RLS na tabela "${table}". Verifique as políticas de acesso no Supabase.`;
        }
        addSyncLog({
          table,
          action: 'ERROR',
          origin: 'LOCAL_APP',
          description: `Erro ao enviar para "${table}": ${cleanMsg}`,
          status: 'error',
        });
        return { success: false, count: uploadedCount, error: cleanMsg };
      }
      uploadedCount += chunk.length;
    }

    const scopeDesc = options?.companyId && options.companyId !== 'ALL'
      ? ` (Empresa: ${options.companyId})`
      : '';
    addSyncLog({
      table,
      action: 'PUSH',
      origin: 'LOCAL_APP',
      description: `Enviados ${uploadedCount} registos da tabela "${table}" para o Supabase com sucesso${scopeDesc}.`,
      status: 'success',
    });

    return { success: true, count: uploadedCount };
  } catch (err: any) {
    const errorMsg = err?.message || String(err);
    return { success: false, count: 0, error: errorMsg };
  }
}

/**
 * ============================================================================
 * PUXAR TODAS AS TABELAS DO SUPABASE (FULL PULL RECONCILIATION)
 * ============================================================================
 */

export async function pullAllFromSupabase(options?: {
  companyId?: string;
  profileId?: string;
}): Promise<{
  success: boolean;
  counts: Record<string, number>;
  data: {
    profiles?: UserProfile[];
    companies?: Company[];
    stores?: Store[];
    products?: Product[];
    customers?: Customer[];
    suppliers?: Supplier[];
    categories?: ProductCategory[];
    sales?: Sale[];
    users?: User[];
    warehouses?: Warehouse[];
    stock?: StockItem[];
    accountsPayable?: AccountPayable[];
    accountsReceivable?: AccountReceivable[];
    shifts?: CashShift[];
    employees?: Employee[];
    timeEntries?: TimeClockEntry[];
    payrolls?: PayrollSlip[];
    employeeShifts?: EmployeeShift[];
    salesGoals?: SalesGoalRecord[];
  };
  errors: string[];
  tableResults: Record<string, { count: number; error?: string; status: 'ok' | 'error' | 'empty' }>;
}> {
  const result: any = {
    success: true,
    counts: {},
    data: {},
    errors: [],
    tableResults: {},
  };

  const fetchTable = async (table: TableSyncName, mapper: (row: any) => any, key: string) => {
    try {
      let query: any = supabase.from(table).select('*');
      
      // Apply multi-tenant company filter if specified (never filter empresas so all companies can be reconciled)
      if (options?.companyId && options.companyId !== 'ALL' && table !== 'empresas') {
        query = query.eq('company_id', options.companyId);
      }

      // Apply specific ordering per table
      if (table === 'produtos' || table === 'categorias' || table === 'lojas' || table === 'armazens') {
        query = query.order('name', { ascending: true });
      } else if (table === 'usuarios') {
        query = query.order('nome', { ascending: true });
      } else if (table === 'vendas') {
        query = query.order('date', { ascending: false });
      } else if (table === 'colaboradores') {
        query = query.order('name', { ascending: true });
      } else if (table === 'registos_ponto') {
        query = query.order('date', { ascending: false });
      } else if (table === 'recibos_salario') {
        query = query.order('month_year', { ascending: false });
      } else if (table === 'escalas_trabalho') {
        query = query.order('date', { ascending: false });
      } else if (table === 'metas_vendas') {
        query = query.order('ano_referencia', { ascending: false });
      } else if (table === 'turnos_caixa') {
        query = query.order('opened_at', { ascending: false });
      }

      // Apply profile filter if specified for profiles table
      if (options?.profileId && options.profileId !== 'ALL' && table === 'profiles') {
        query = query.eq('id', options.profileId);
      }

      const { data, error } = await query;
      if (error) {
        const errorMsg = isTableMissingError(error)
          ? `Tabela "${table}" ainda não existe no Supabase (execute o script SQL).`
          : `Erro na tabela "${table}": ${error.message}`;
        result.errors.push(errorMsg);
        result.counts[table] = 0;
        result.tableResults[table] = { count: 0, error: errorMsg, status: 'error' };
        return;
      }
      if (Array.isArray(data)) {
        let mappedData = data.map(mapper);
        if (table === 'produtos') {
          mappedData = mappedData.sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt', { sensitivity: 'base', numeric: true }));
        }

        // Descartar permanentemente registos de empresas eliminadas
        if (table === 'empresas') {
          mappedData = mappedData.filter((c: any) => c && c.id && !isCompanyDeleted(c.id, c.name));
        } else if (table === 'usuarios') {
          mappedData = mappedData.filter((u: any) => u && !isCompanyDeleted(u.companyId));
        } else {
          mappedData = mappedData.filter((item: any) => {
            const cId = item?.companyId || item?.company_id;
            return !cId || !isCompanyDeleted(cId);
          });
        }

        result.data[key] = mappedData;
        result.counts[table] = mappedData.length;
        result.tableResults[table] = {
          count: mappedData.length,
          status: mappedData.length > 0 ? 'ok' : 'empty',
        };
      }
    } catch (e: any) {
      const errTxt = `Falha ao ler ${table}: ${e.message || e}`;
      result.errors.push(errTxt);
      result.tableResults[table] = { count: 0, error: errTxt, status: 'error' };
    }
  };

  await Promise.all([
    fetchTable('profiles', mapSupabaseToProfile, 'profiles'),
    fetchTable('empresas', mapSupabaseToCompany, 'companies'),
    fetchTable('lojas', mapSupabaseToStore, 'stores'),
    fetchTable('usuarios', mapSupabaseToUser, 'users'),
    fetchTable('categorias', mapSupabaseToCategory, 'categories'),
    fetchTable('produtos', mapSupabaseToProduct, 'products'),
    fetchTable('clientes', mapSupabaseToCustomer, 'customers'),
    fetchTable('fornecedores', mapSupabaseToSupplier, 'suppliers'),
    fetchTable('armazens', mapSupabaseToWarehouse, 'warehouses'),
    fetchTable('stock', mapSupabaseToStock, 'stock'),
    fetchTable('vendas', mapSupabaseToSale, 'sales'),
    fetchTable('contas_pagar', mapSupabaseToAccountPayable, 'accountsPayable'),
    fetchTable('contas_receber', mapSupabaseToAccountReceivable, 'accountsReceivable'),
    fetchTable('turnos_caixa', mapSupabaseToShift, 'shifts'),
    fetchTable('colaboradores', mapSupabaseToEmployee, 'employees'),
    fetchTable('registos_ponto', mapSupabaseToTimeEntry, 'timeEntries'),
    fetchTable('recibos_salario', mapSupabaseToPayroll, 'payrolls'),
    fetchTable('escalas_trabalho', mapSupabaseToEmployeeShift, 'employeeShifts'),
    fetchTable('metas_vendas', mapSupabaseToSalesGoal, 'salesGoals'),
  ]);

  result.success = result.errors.length === 0;

  const scopeMsg = options?.companyId && options.companyId !== 'ALL'
    ? ` [Empresa: ${options.companyId}]`
    : ' [Geral - Todas Empresas]';

  addSyncLog({
    table: 'ALL',
    action: 'PULL',
    origin: 'LOCAL_APP',
    description: result.success
      ? `Sincronização completa concluída com sucesso (${Object.values(result.counts).reduce((a: any, b: any) => a + b, 0)} registos obtidos)${scopeMsg}.`
      : `Sincronização concluída com avisos em ${result.errors.length} tabelas${scopeMsg}.`,
    status: result.success ? 'success' : 'info',
  });

  return result;
}

/**
 * ============================================================================
 * ENVIAR TODOS OS DADOS LOCAIS PARA O SUPABASE (FULL PUSH)
 * ============================================================================
 */

export async function pushAllToSupabase(
  localData: {
    profiles?: UserProfile[];
    companies?: Company[];
    stores?: Store[];
    products: Product[];
    customers: Customer[];
    suppliers: Supplier[];
    categories: ProductCategory[];
    sales: Sale[];
    users: User[];
    warehouses: Warehouse[];
    stock: StockItem[];
    accountsPayable: AccountPayable[];
    accountsReceivable: AccountReceivable[];
    shifts: CashShift[];
    employees?: Employee[];
    timeEntries?: TimeClockEntry[];
    payrolls?: PayrollSlip[];
    employeeShifts?: EmployeeShift[];
    salesGoals?: SalesGoalRecord[];
  },
  options?: {
    companyId?: string;
    profileId?: string;
  }
): Promise<{
  success: boolean;
  uploaded: Record<string, number>;
  errors: string[];
  tableResults: Record<string, { count: number; error?: string; status: 'ok' | 'error' | 'empty' }>;
}> {
  const result = {
    success: true,
    uploaded: {} as Record<string, number>,
    errors: [] as string[],
    tableResults: {} as Record<string, { count: number; error?: string; status: 'ok' | 'error' | 'empty' }>,
  };

  const uploadBatch = async (table: TableSyncName, items: any[] | undefined, mapper: (item: any) => any) => {
    if (!items || items.length === 0) {
      result.uploaded[table] = 0;
      result.tableResults[table] = { count: 0, status: 'empty' };
      return;
    }
    try {
      let payload = items.map(mapper);

      // Multi-tenant scope tagging
      if (options?.companyId && options.companyId !== 'ALL') {
        payload = payload.map((row) => {
          if (table === 'empresas') {
            return { ...row, id: row.id || options.companyId };
          }
          return { ...row, company_id: options.companyId };
        });
      }

      const CHUNK_SIZE = 50;
      let totalForTable = 0;

      for (let i = 0; i < payload.length; i += CHUNK_SIZE) {
        const chunk = payload.slice(i, i + CHUNK_SIZE);
        const { error } = await supabase.from(table).upsert(chunk);
        if (error) {
          let errorMsg = `Erro na tabela "${table}": ${error.message}`;
          if (isTableMissingError(error)) {
            errorMsg = `Tabela "${table}" ainda não existe no Supabase. Execute o script SQL no Supabase.`;
          } else if (error.code === '42501' || error.message?.includes('row-level security') || error.message?.includes('policy')) {
            errorMsg = `Permissão negada (RLS) na tabela "${table}". Verifique as políticas de segurança.`;
          }
          result.errors.push(errorMsg);
          result.uploaded[table] = totalForTable;
          result.tableResults[table] = { count: totalForTable, error: errorMsg, status: 'error' };
          return;
        }
        totalForTable += chunk.length;
      }

      result.uploaded[table] = totalForTable;
      result.tableResults[table] = { count: totalForTable, status: 'ok' };
    } catch (e: any) {
      const errTxt = `Erro ao exportar ${table}: ${e.message || e}`;
      result.errors.push(errTxt);
      result.uploaded[table] = 0;
      result.tableResults[table] = { count: 0, error: errTxt, status: 'error' };
    }
  };

  // Derive profiles from users if not explicitly provided
  const profilesToSync: Partial<UserProfile>[] = localData.profiles && localData.profiles.length > 0
    ? localData.profiles
    : (localData.users || []).map((u) => ({
        id: u.id,
        company_id: u.companyId || options?.companyId || 'comp-1',
        full_name: u.name || 'Utilizador',
        email: u.email || `${u.id}@empresa.mz`,
        role: (u.role || 'caixa') as any,
      }));

  // Upload in logical sequence: profiles, companies & stores first, then users, etc.
  await uploadBatch('profiles', profilesToSync, mapProfileToSupabase);
  await uploadBatch('empresas', localData.companies, mapCompanyToSupabase);
  await uploadBatch('lojas', localData.stores, mapStoreToSupabase);
  await uploadBatch('usuarios', localData.users, mapUserToSupabase);
  await uploadBatch('categorias', localData.categories, mapCategoryToSupabase);
  await uploadBatch('armazens', localData.warehouses, mapWarehouseToSupabase);
  await uploadBatch('fornecedores', localData.suppliers, mapSupplierToSupabase);
  await uploadBatch('clientes', localData.customers, mapCustomerToSupabase);
  await uploadBatch('produtos', localData.products, mapProductToSupabase);
  await uploadBatch('stock', localData.stock, mapStockToSupabase);
  await uploadBatch('vendas', localData.sales, mapSaleToSupabase);
  await uploadBatch('contas_pagar', localData.accountsPayable, mapAccountPayableToSupabase);
  await uploadBatch('contas_receber', localData.accountsReceivable, mapAccountReceivableToSupabase);
  await uploadBatch('turnos_caixa', localData.shifts, mapShiftToSupabase);
  await uploadBatch('colaboradores', localData.employees, mapEmployeeToSupabase);
  await uploadBatch('registos_ponto', localData.timeEntries, mapTimeEntryToSupabase);
  await uploadBatch('recibos_salario', localData.payrolls, mapPayrollToSupabase);
  await uploadBatch('escalas_trabalho', localData.employeeShifts, mapEmployeeShiftToSupabase);
  await uploadBatch('metas_vendas', localData.salesGoals, mapSalesGoalToSupabase);

  result.success = result.errors.length === 0;

  const totalCount = Object.values(result.uploaded).reduce((a, b) => a + b, 0);
  const scopeMsg = options?.companyId && options.companyId !== 'ALL'
    ? ` [Empresa: ${options.companyId}]`
    : ' [Geral - Todas Empresas]';

  addSyncLog({
    table: 'ALL',
    action: 'PUSH',
    origin: 'LOCAL_APP',
    description: result.success
      ? `Exportação total para o Supabase concluída com sucesso (${totalCount} registos enviados em 19 tabelas)${scopeMsg}.`
      : `Exportação para o Supabase concluída com ${result.errors.length} erro(s). ${totalCount} registos enviados${scopeMsg}.`,
    status: result.success ? 'success' : 'error',
  });

  return result;
}

/**
 * Fecha em definitivo quaisquer turnos que tenham ficado abertos para uma determinada empresa no Supabase.
 * Isso garante que nenhum dispositivo secundário encontre um turno "aberto" órfão após o fecho de caixa.
 */
export async function closeAllOpenShiftsInSupabase(
  companyId: string,
  closedAt?: string
): Promise<{ success: boolean; error?: any }> {
  try {
    const closeTime = closedAt || new Date().toISOString();
    const { error } = await supabase
      .from('turnos_caixa')
      .update({
        status: 'fechado',
        closed_at: closeTime,
        updated_at: closeTime,
      })
      .eq('company_id', companyId)
      .eq('status', 'aberto');

    if (error) {
      if (!isTableMissingError(error)) {
        console.warn('[closeAllOpenShiftsInSupabase] Supabase update warning:', error.message);
      }
      return { success: false, error };
    }
    return { success: true };
  } catch (err: any) {
    console.warn('[closeAllOpenShiftsInSupabase] Exception:', err);
    return { success: false, error: err };
  }
}

/**
 * Consulta especificamente o último turno registado para a empresa no Supabase.
 * Ordenado decrescentemente por data de abertura (o mais recente primeiro).
 */
export async function fetchLatestShiftFromSupabase(companyId: string): Promise<CashShift | null> {
  try {
    const { data, error } = await supabase
      .from('turnos_caixa')
      .select('*')
      .eq('company_id', companyId)
      .order('opened_at', { ascending: false })
      .limit(1);

    if (error || !data || data.length === 0) {
      return null;
    }
    return mapSupabaseToShift(data[0]);
  } catch (err) {
    console.warn('[fetchLatestShiftFromSupabase] Exception:', err);
    return null;
  }
}

/**
 * Elimina completamente todos os dados e informações de uma empresa no Supabase:
 * Remove em cascata registos em todas as tabelas multi-tenant associadas à empresa (company_id)
 * e por fim elimina o registo da empresa na tabela 'empresas'.
 */
export async function purgeCompanyFromSupabase(
  companyId: string,
  companyName?: string
): Promise<{ success: boolean; deletedCount: number; errors: any[] }> {
  const errors: any[] = [];
  let deletedCount = 0;

  // Lista de todas as tabelas multi-tenant vinculadas por company_id
  const childTables: TableSyncName[] = [
    'metas_vendas',
    'escalas_trabalho',
    'recibos_salario',
    'registos_ponto',
    'colaboradores',
    'turnos_caixa',
    'contas_receber',
    'contas_pagar',
    'vendas',
    'stock',
    'armazens',
    'produtos',
    'categorias',
    'clientes',
    'fornecedores',
    'usuarios',
    'lojas',
    'profiles',
  ];

  for (const table of childTables) {
    try {
      const { error, count } = await supabase
        .from(table)
        .delete({ count: 'exact' })
        .eq('company_id', companyId);

      if (error) {
        if (!isTableMissingError(error)) {
          console.warn(`[purgeCompanyFromSupabase] Aviso ao eliminar registos de ${table}:`, error.message);
          errors.push({ table, error: error.message });
        }
      } else if (count) {
        deletedCount += count;
      }

      // Se profiles ou usuarios tiverem sido salvos com o nome da empresa como company_id
      if (companyName && companyName.trim() && companyName !== companyId && (table === 'profiles' || table === 'usuarios')) {
        try {
          const { count: nameCount } = await supabase
            .from(table)
            .delete({ count: 'exact' })
            .eq('company_id', companyName.trim());
          if (nameCount) deletedCount += nameCount;
        } catch {}
      }
    } catch (err: any) {
      if (!isTableMissingError(err)) {
        errors.push({ table, error: err?.message || String(err) });
      }
    }
  }

  // Eliminar na tabela principal 'empresas'
  try {
    const { error, count } = await supabase
      .from('empresas')
      .delete({ count: 'exact' })
      .eq('id', companyId);

    if (error) {
      if (!isTableMissingError(error)) {
        console.warn('[purgeCompanyFromSupabase] Aviso ao eliminar da tabela empresas:', error.message);
        errors.push({ table: 'empresas', error: error.message });
      }
    } else if (count) {
      deletedCount += count;
    }

    // Se companyName for fornecido, eliminar também por name e trade_name
    if (companyName && companyName.trim() && companyName.trim() !== companyId) {
      const cleanCompName = companyName.trim();
      try {
        const { count: c1 } = await supabase.from('empresas').delete({ count: 'exact' }).eq('name', cleanCompName);
        if (c1) deletedCount += c1;
      } catch {}
      try {
        const { count: c2 } = await supabase.from('empresas').delete({ count: 'exact' }).eq('trade_name', cleanCompName);
        if (c2) deletedCount += c2;
      } catch {}
    }
  } catch (err: any) {
    if (!isTableMissingError(err)) {
      errors.push({ table: 'empresas', error: err?.message || String(err) });
    }
  }

  // Purgar dados locais em cache no IndexedDB
  try {
    await offlineDB.purgeCompanyData(companyId);
  } catch (err) {
    console.warn('[purgeCompanyFromSupabase] Aviso ao limpar dados no IndexedDB:', err);
  }

  addSyncLog({
    table: 'empresas',
    action: 'DELETE',
    origin: 'LOCAL_APP',
    description: `Empresa "${companyId}" e todos os seus registos foram eliminados no Supabase (${deletedCount} registos eliminados).`,
    status: errors.length === 0 ? 'success' : 'info',
  });

  return { success: errors.length === 0, deletedCount, errors };
}

/**
 * Remove todos os itens bloqueados por erro de RLS (42501) da fila de sincronização IndexedDB.
 */
export async function clearRlsItemsFromSyncQueue(): Promise<number> {
  try {
    const queue = await offlineDB.getPendingSyncQueue();
    let removedCount = 0;
    for (const item of queue) {
      const isRls =
        item.table === 'clientes' ||
        (item.lastError &&
          (item.lastError.includes('row-level security') ||
            item.lastError.includes('42501') ||
            item.lastError.includes('RLS')));
      if (isRls) {
        await offlineDB.removeSyncQueueItem(item.id);
        removedCount++;
      }
    }
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('offline_sync_queue_changed', { detail: { action: 'clear_rls', removedCount } })
      );
    }
    addSyncLog({
      table: 'clientes',
      action: 'DELETE',
      origin: 'LOCAL_APP',
      description: `🧹 Limpeza da fila: ${removedCount} operações bloqueadas por RLS foram removidas da fila local.`,
      status: 'info',
    });
    return removedCount;
  } catch (err) {
    console.error('Erro ao limpar itens de RLS da fila:', err);
    return 0;
  }
}

/**
 * Limpa completamente a fila de sincronização pendente no IndexedDB e localStorage.
 */
export async function clearAllPendingSyncQueue(): Promise<void> {
  try {
    await offlineDB.clearSyncQueue();
    localStorage.removeItem(PENDING_SYNC_STORAGE_KEY);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('offline_sync_queue_changed', { detail: { action: 'clear_all' } }));
    }
    addSyncLog({
      table: 'ALL',
      action: 'DELETE',
      origin: 'LOCAL_APP',
      description: '🧹 Fila de sincronização offline limpa com sucesso.',
      status: 'info',
    });
  } catch (err) {
    console.error('Erro ao limpar fila de sincronização offline:', err);
  }
}


